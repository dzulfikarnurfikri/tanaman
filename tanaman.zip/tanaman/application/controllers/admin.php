<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function index()
	{
		if(!$this->session->userdata('id_admin')){
			redirect('admin/login');
		}else{
			$this->load->view('admin/v_beranda');
		}
	}

	function login(){
		$this->load->view('admin/v_login');
	}

	function proseslogin(){
		$mail 	= $this->input->post('email',true);
		$pass 	= $this->input->post('pass',true);
		$cek 	= $this->Model_adm->ceklogin($mail,$pass);
		$nama 	= $cek->nama_admin;
		$id 	= $cek->id_admin;
		$status = $cek->level;

		if(count($cek) > 0){
			$data = array('logged_in' => true,
					'nama_admin' => $nama,
					'id_admin' => $id,
					'status_admin' => $status);
			$this->session->set_userdata($data);
			redirect('admin');
		}else{
			$this->session->set_flashdata('err','<div class="alert alert-danger"><b>Maaf,</b> email atau password Anda salah <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
			redirect('admin/login');
		}
	}

	function logout(){
		$this->session->sess_destroy();
		redirect('admin/login');
	}

	function artikel(){
		if(!$this->session->userdata('id_admin')){
			redirect('admin/login');
		}else{
			$this->data['art'] = $this->Model_adm->getData('artikel');
			$this->load->view('admin/v_artikel',$this->data);
		}
	}

	function bbp(){
		if(!$this->session->userdata('id_admin')){
			redirect('admin/login');
		}else{
			$this->data['bayar'] = $this->Model_adm->getData('pembayaran');
			$this->load->view('admin/v_bbp',$this->data);
		}
	}

	function pelanggan(){
		if(!$this->session->userdata('id_admin')){
			redirect('admin/login');
		}else{
			if($this->input->post('tgl1',true) != ''){
				$tanggal = array('tanggal_awal' => $this->input->post('tgl1',true),
								'tanggal_akhir' => $this->input->post('tgl2',true));
				$this->session->set_userdata($tanggal);
				$this->data['pelanggan'] = $this->Model_adm->getBetweens('pelanggan',$this->input->post('tgl1',true),$this->input->post('tgl2',true));
			}else{
				$this->session->unset_userdata('tanggal_akhir');
				$this->session->unset_userdata('tanggal_awal');
				$this->data['pelanggan'] = $this->Model_adm->getData('pelanggan');
			}
			$this->load->view('admin/v_pelanggan',$this->data);
		}
	}

	function pemesanan(){
		if(!$this->session->userdata('id_admin')){
			redirect('admin/login');
		}else{
			$this->data['pesan'] = $this->Model_adm->getData('pemesanan');
			$this->load->view('admin/v_datapemesanan',$this->data);
		}
	}

	function penjual(){
		if(!$this->session->userdata('id_admin')){
			redirect('admin/login');
		}else{
			if($this->input->post('tgl1',true) != ''){
				$tanggal = array('tanggal_awal' => $this->input->post('tgl1',true),
								'tanggal_akhir' => $this->input->post('tgl2',true));
				$this->session->set_userdata($tanggal);
				$this->data['penjual'] = $this->Model_adm->getBetweens('penjual',$this->input->post('tgl1',true),$this->input->post('tgl2',true));
			}else{
				$this->session->unset_userdata('tanggal_akhir');
				$this->session->unset_userdata('tanggal_awal');
				$this->data['penjual'] = $this->Model_adm->getData('penjual');
			}
			$this->load->view('admin/v_penjual',$this->data);
		}
	}

	function produk(){
		if(!$this->session->userdata('id_admin')){
			redirect('admin/login');
		}else{
			$this->data['produk'] = $this->Model_adm->getData('produk');
			$this->load->view('admin/v_produk',$this->data);
		}
	}

	function laporanproduk(){
		if(!$this->session->userdata('id_admin')){
			redirect('admin/login');
		}else{
			$this->data['produk'] = $this->Model_adm->getData('produk');
			$this->load->view('admin/v_laporan_produk',$this->data);
		}
	}


	function penjualan(){
		if(!$this->session->userdata('id_admin')){
			redirect('admin/login');
		}else{
			if($this->input->post('tgl1',true) != ''){
				$tanggal = array('tanggal_awal' => $this->input->post('tgl1',true),
								'tanggal_akhir' => $this->input->post('tgl2',true));
				$this->session->set_userdata($tanggal);
				$this->data['pesan'] = $this->Model_adm->getBetween('pemesanan',$this->input->post('tgl1',true),$this->input->post('tgl2',true));
			}else{
				$this->session->unset_userdata('tanggal_akhir');
				$this->session->unset_userdata('tanggal_awal');
				$this->data['pesan'] = $this->Model_adm->getDetailArray('status','pemesanan','lunas');
			}
			$this->load->view('admin/v_penjualan',$this->data);
		}
	}	

	function tambah_artikel(){
		if(!$this->session->userdata('id_admin')){
			redirect('admin/login');
		}else{
			$this->load->view('admin/v_tambah_artikel');
		}
	}

	function prosestambahartikel(){
		$config['upload_path'] = './artikelimg/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		$config['max_size']	= '10000'; // max 10 MB
		$config['max_width']  = '6000';
		$config['max_height']  = '6000';

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload())
		{
			$error = array('error' => $this->upload->display_errors());
			$this->session->set_flashdata('notif-error','<script> alert("gagal"); </script>');
			redirect('admin/tambah_artikel');
		}
		else
		{
			$this->db->select_max('id_artikel', 'atas');
			$max = $this->db->get('artikel')->row();
			$max1 = $max->atas;
			$max2 = substr($max1, 1,4);
			$max3 = $max2 + 1;
			$max4 = "A".sprintf("%04s",$max3);

			$img = $this->upload->data();
			$data = array('id_artikel' => $max4,'judul' => $this->input->post('judul',true),
			'gambar' => $img['file_name'],
			'isi' => $this->input->post('area2',true));
			$this->Model_adm->inputData('artikel',$data);
			$this->session->set_flashdata('notif-oke','<script> alert("berhasil disimpan"); </script>');
			redirect('admin/tambah_artikel');
		}
	}

	function hapusartikel($id){
		$this->Model_adm->deleteData('id_artikel','artikel',$id);
		redirect('admin/artikel');
	}

	function hapusproduk($id){
		$this->Model_adm->deleteData('id_produk','produk',$id);
		redirect('admin/produk');
	}

	function hapusbayar($id){
		$this->Model_adm->deleteData('id_pembayaran','pembayaran',$id);
		redirect('admin/bbp');
	}

	function hapuspelanggan($id){
		$this->Model_adm->deleteData('id_pelanggan','pelanggan',$id);
		redirect('admin/pelanggan');
	}

	function hapuspenjual($id){
		$this->Model_adm->deleteData('id_penjual','penjual',$id);
		redirect('admin/penjual');
	}

	function edit_artikel(){
		if(!$this->session->userdata('id_admin')){
			redirect('admin/login');
		}else{
			$this->data['art'] = $this->Model_adm->getDetail('id_artikel','artikel',$this->input->post('id',true));
			$this->load->view('admin/v_edit_artikel',$this->data);
		}
	}

	function lunas($id=NULL){
		$data = array('status' => 'lunas');
		$this->Model_adm->updateData('id_pemesanan','pemesanan',$data,$id);
		redirect('admin/bbp');
	}

	function proseseditartikel(){
		$isi_gbr = $_FILES['userfile']['name'];
		if($isi_gbr != ""){
			$config['upload_path'] = './artikelimg/';
			$config['allowed_types'] = 'gif|jpg|png|jpeg';
			$config['max_size']	= '10000'; // max 10 MB
			$config['max_width']  = '6000';
			$config['max_height']  = '6000';

			$this->load->library('upload', $config);

			if ( ! $this->upload->do_upload())
			{
				$error = array('error' => $this->upload->display_errors());
				$this->session->set_flashdata('notif-error','<script> alert("Gagal Edit"); </script>');
				redirect('admin/artikel');
			}
			else
			{
				$img = $this->upload->data();
				$data = array('judul' => $this->input->post('judul',true),
				'gambar' => $img['file_name'],
				'isi' => $this->input->post('area2',true));
				$this->Model_adm->updateData('id_artikel','artikel',$data,$this->input->post('id',true));
				$this->session->set_flashdata('notif-oke','<script> alert("Berhasil Edit"); </script>');
				redirect('admin/artikel');
			}
		}else{
				$data = array('judul' => $this->input->post('judul',true),
				'gambar' => $this->input->post('gambar',true),
				'isi' => $this->input->post('area2',true));
				$this->Model_adm->updateData('id_artikel','artikel',$data,$this->input->post('id',true));
				$this->session->set_flashdata('notif-oke','<script> alert("Berhasil Edit"); </script>');
				redirect('admin/artikel');
		}
	}

	function konfirmasiproduk($id=0){
		if(!$this->session->userdata('id_admin')){
			redirect('admin/login');
		}else{
			$this->data['produk'] = $this->Model_adm->getjoinDetailSatu('id_produk','produk',$id);
			$this->load->view('admin/v_konfirmasi_produk',$this->data);
		}
	}

	function proseskonfirm(){
		$data = array('status' => $this->input->post('stat',true));
		$this->Model_adm->updateData('id_produk','produk',$data,$this->input->post('id',true));
		redirect('admin/produk');
	}

	function cetakPenjual($download_pdf =''){
		$ret = '';
		$id = 1;
		$pdf_filename = 'penjual'.$id.'.pdf';
		if($this->session->userdata('tanggal_awal')){
			$info = $this->Model_adm->getBetweens('penjual',$this->session->userdata('tanggal_awal'),$this->session->userdata('tanggal_akhir'));
		}else{
			$info = $this->Model_adm->getData('penjual');
		}

		$halaman = array(
			'penjual' => $info,
			'tgl1' => $this->session->userdata('tanggal_awal'),
			'tgl2' => $this->session->userdata('tanggal_akhir'));

		$file = $this->load->view('admin/cetak_penjual',$halaman, true);

		$output = $file;

		if($download_pdf == TRUE){
			generate_pdf($output,$pdf_filename);
		}else{
			echo $output;
		}
	}

	function cetakPelanggan($download_pdf =''){
		$ret = '';
		$id = 1;
		$pdf_filename = 'pelanggan'.$id.'.pdf';
		if($this->session->userdata('tanggal_awal')){
			$info = $this->Model_adm->getBetweens('pelanggan',$this->session->userdata('tanggal_awal'),$this->session->userdata('tanggal_akhir'));
		}else{
			$info = $this->Model_adm->getData('pelanggan');
		}
		

		$halaman = array(
			'pelanggan' => $info,
			'tgl1' => $this->session->userdata('tanggal_awal'),
			'tgl2' => $this->session->userdata('tanggal_akhir'));

		$file = $this->load->view('admin/cetak_pelanggan',$halaman, true);

		$output = $file;

		if($download_pdf == TRUE){
			generate_pdf($output,$pdf_filename);
		}else{
			echo $output;
		}
	}

	function cetakProduk($download_pdf =''){
		$ret = '';
		$id = 1;
		$pdf_filename = 'produk'.$id.'.pdf';
		
		$info = $this->Model_adm->getData('produk');

		$halaman = array(
			'produk' => $info);

		$file = $this->load->view('admin/cetak_produk',$halaman, true);

		$output = $file;

		if($download_pdf == TRUE){
			generate_pdf($output,$pdf_filename);
		}else{
			echo $output;
		}
	}

	function cetakPenjualan($download_pdf =''){
		$ret = '';
		$id = 1;
		$pdf_filename = 'penjualan'.$id.'.pdf';
		if($this->session->userdata('tanggal_awal')){
 			$info = $this->Model_adm->getBetween('pemesanan',$this->session->userdata('tanggal_awal'),$this->session->userdata('tanggal_akhir'));
		}else{
			$info = $this->Model_adm->getDetailArray('status','pemesanan','lunas');
		}

		$halaman = array(
			'pesan' => $info,
			'tgl1' => $this->session->userdata('tanggal_awal'),
			'tgl2' => $this->session->userdata('tanggal_akhir'));

		$file = $this->load->view('admin/cetak_penjualan',$halaman, true);

		$output = $file;

		if($download_pdf == TRUE){
			generate_pdf($output,$pdf_filename);
		}else{
			echo $output;
		}
	}

	function cetakInvoice($idi=NULL,$download_pdf =''){
		$ret = '';
		$id = 1;
		$pdf_filename = 'invoice'.$id.'.pdf';
		
		$this->data['pesan'] = $this->Model_usr->getjoinDetailArray('id_pemesanan','detail_pemesanan',$idi);
		$this->db->select_sum('harga');
		$this->data['sum'] = $this->db->get_where('detail_pemesanan',array('id_pemesanan' => $idi))->row();

		$file = $this->load->view('admin/cetak_invoice',$this->data, true);

		$output = $file;

		if($download_pdf == TRUE){
			generate_pdf($output,$pdf_filename);
		}else{
			echo $output;
		}
	}

	function prosesselesai($id=NULL){
		$data = array('tahap' => 'selesai');
		$update = $this->Model_adm->updateData('id_pemesanan','pemesanan',$data,$id);
		redirect('admin/pemesanan');
	}

	function detailpemesanan($id=NULL){
		if(!$this->session->userdata('id_admin')){
			redirect('admin/login');
		}else{
			$this->data['id'] = $id;
			$this->data['pesan'] = $this->Model_usr->getjoinDetailArray('id_pemesanan','detail_pemesanan',$id);
			$this->db->select_sum('harga');
			$this->data['sum'] = $this->db->get_where('detail_pemesanan',array('id_pemesanan' => $id))->row();
			$this->load->view('admin/v_detaildatapemesanan',$this->data);
		}
	}

	function hapuspemesanan($id=NULL){
		$this->Model_usr->deleteData('id_pemesanan','pemesanan',$id);
		$this->Model_usr->deleteData('id_pemesanan','detail_pemesanan',$id);
		redirect('admin/pemesanan');
	}
}