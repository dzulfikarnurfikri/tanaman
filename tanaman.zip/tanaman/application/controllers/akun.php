<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Akun extends CI_Controller {

	public function index()
	{
		if(!$this->session->userdata('idu')){
			redirect('masuk');
		}else{
			if($this->session->userdata('status') == 'penjual'){
				$this->data['user'] = $this->Model_usr->getDetail('id_penjual','penjual',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_penjual;
				$this->data['toko'] = $this->data['user']->toko;
				$this->data['foto'] = $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_penjual;
				$this->data['email']= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_akun',$this->data);
			}else{
				$this->data['user'] = $this->Model_usr->getDetail('id_pelanggan','pelanggan',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_pelanggan;
				$this->data['nama']	= $this->data['user']->nama_pelanggan;
				$this->data['foto'] 	= $this->data['user']->foto;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_akun',$this->data);
			}
		}
	}

	function update($id=0){
		if(!$this->session->userdata('idu')){
			redirect('masuk');
		}else{
			if($this->session->userdata('status') == 'penjual'){
				$this->data['user'] = $this->Model_usr->getDetail('id_penjual','penjual',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_penjual;
				$this->data['foto'] 	= $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_penjual;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_update_akun',$this->data);
			}else{
				$this->data['user'] = $this->Model_usr->getDetail('id_pelanggan','pelanggan',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_pelanggan;
				$this->data['foto'] 	= $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_pelanggan;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_update_akun',$this->data);
			}
		}
	}

	function prosesupdate(){
		$id 	 = $this->session->userdata('idu');
		$nama 	 = ucwords($this->input->post('nama',true));
		$telp 	 = $this->input->post('telp',true);
		$email 	 = $this->input->post('email',true);
		$pass1 	 = $this->input->post('pass1',true);
		$pass2 	 = $this->input->post('pass2',true);
		$jk 	 = $this->input->post('jks',true);
		$alamat  = $this->input->post('alamat',true);
		$tgl 	 = $this->input->post('tgl',true);
		$bln 	 = $this->input->post('bln',true);
		$thn 	 = $this->input->post('thn',true);
		$ttlpass = strlen($pass1);
		$ttltelp = strlen($telp);

		$isi_gbr = $_FILES['userfile']['name'];
		if($isi_gbr != ""){ 
			$config['upload_path'] = './foto/';
			$config['allowed_types'] = 'gif|jpg|png|jpeg';
			$config['max_size']	= '10000'; // max 10 MB
			$config['max_width']  = '6000';
			$config['max_height']  = '6000';

			$this->load->library('upload', $config);

			if ( ! $this->upload->do_upload())
			{
				$error = array('error' => $this->upload->display_errors());
				$this->session->set_flashdata('notif-error','<script> alert("Gagal Edit"); </script>');
				redirect('akun');
			}
			else
			{
				if(!is_numeric($telp)){
					$this->session->set_flashdata('err','<div class="alert alert-danger"><b>Maaf,</b> Nomor telepon harus angka. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
						redirect('akun/update/'.$id);
				}elseif($ttltelp < 10){
					$this->session->set_flashdata('err','<div class="alert alert-danger"><b>Maaf,</b> telepon harus 10 - 13 karakter. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
						redirect('akun/update/'.$id);
				}elseif($ttlpass < 6){
					$this->session->set_flashdata('err','<div class="alert alert-danger"><b>Maaf,</b> Password minimal 6 karakter. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
						redirect('akun/update/'.$id);
				}elseif($pass2 != $pass1){
					$this->session->set_flashdata('err','<div class="alert alert-danger"><b>Maaf,</b> Password tidak sesuai. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
						redirect('akun/update/'.$id);
				}else{
					$img = $this->upload->data();
					if($this->session->userdata('status') == 'penjual'){
						$data 	= array(
									'nama_penjual' => $nama,
									'email' => $email,
									'tanggal_lahir' => $tgl,
									'bulan_lahir' => $bln,
									'tahun_lahir' => $thn,
									'telepon' => $telp,
									'alamat' => $alamat,
									'jenis_kelamin' => $jk,
									'password' => $pass1,
									'foto' => $img['file_name']);
						$insert = $this->Model_usr->updateData('id_penjual','penjual',$data,$id);
					}else{
						$data 	= array(
									'nama_pelanggan' => $nama,
									'email' => $email,
									'tanggal_lahir' => $tgl,
									'bulan_lahir' => $bln,
									'tahun_lahir' => $thn,
									'telepon' => $telp,
									'alamat' => $alamat,
									'jenis_kelamin' => $jk,
									'password' => $pass1,
									'foto' => $img['file_name']);
						$insert = $this->Model_usr->updateData('id_pelanggan','pelanggan',$data,$id);
					}
					if($insert > 0){
						$this->session->set_flashdata('notif_oke2','<div class="alert alert-success"><b>Selamat,</b> biodata anda berhasil diubah. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
						redirect('akun');
					}
				}
			}
		}else{ 
			if(!is_numeric($telp)){
					$this->session->set_flashdata('err','<div class="alert alert-danger"><b>Maaf,</b> Nomor telepon harus angka. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
						redirect('akun/update/'.$id);
				}elseif($ttltelp < 10){
					$this->session->set_flashdata('err','<div class="alert alert-danger"><b>Maaf,</b> telepon harus 10 - 13 karakter. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
						redirect('akun/update/'.$id);
				}elseif($ttlpass < 6){
					$this->session->set_flashdata('err','<div class="alert alert-danger"><b>Maaf,</b> Password minimal 6 karakter. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
						redirect('akun/update/'.$id);
				}elseif($pass2 != $pass1){
					$this->session->set_flashdata('err','<div class="alert alert-danger"><b>Maaf,</b> Password tidak sesuai. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
						redirect('akun/update/'.$id);
				}else{
					if($this->session->userdata('status') == 'penjual'){
						$data 	= array(
									'nama_penjual' => $nama,
									'email' => $email,
									'tanggal_lahir' => $tgl,
									'bulan_lahir' => $bln,
									'tahun_lahir' => $thn,
									'telepon' => $telp,
									'alamat' => $alamat,
									'jenis_kelamin' => $jk,
									'password' => $pass1,
									'foto' => $this->input->post('gambar',true));
						$insert = $this->Model_usr->updateData('id_penjual','penjual',$data,$id);
					}else{
						$data 	= array(
									'nama_pelanggan' => $nama,
									'email' => $email,
									'tanggal_lahir' => $tgl,
									'bulan_lahir' => $bln,
									'tahun_lahir' => $thn,
									'telepon' => $telp,
									'alamat' => $alamat,
									'jenis_kelamin' => $jk,
									'password' => $pass1,
									'foto' => $this->input->post('gambar',true));
						$insert = $this->Model_usr->updateData('id_pelanggan','pelanggan',$data,$id);
					}
					if($insert > 0){
						$this->session->set_flashdata('notif_oke2','<div class="alert alert-success"><b>Selamat,</b> biodata anda berhasil diubah. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
						redirect('akun');
					}
				}
		}
	}

	function produkUser(){
		if(!$this->session->userdata('idu')){
			redirect('masuk');
		}else{
			if($this->session->userdata('status') == 'penjual'){
				$this->data['produk'] = $this->Model_usr->getProdukUser('id_penjual','produk',$this->session->userdata('idu'));
				$this->data['user'] = $this->Model_usr->getDetail('id_penjual','penjual',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_penjual;
				$this->data['foto'] 	= $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_penjual;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_produk_user',$this->data);
			}else{
				$this->data['user'] = $this->Model_usr->getDetail('id_pelanggan','pelanggan',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_pelanggan;
				$this->data['foto'] 	= $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_pelanggan;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_produk_user',$this->data);
			}
		}
	}

	function orderUser(){
		if(!$this->session->userdata('idu')){
			redirect('masuk');
		}else{
			if($this->session->userdata('status') == 'penjual'){
				$this->data['pesan'] = $this->Model_usr->getData('pemesanan');
				$this->data['user'] = $this->Model_usr->getDetail('id_penjual','penjual',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_penjual;
				$this->data['foto'] 	= $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_penjual;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_order_user',$this->data);
			}else{
				$this->data['user'] = $this->Model_usr->getDetail('id_pelanggan','pelanggan',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_pelanggan;
				$this->data['foto'] 	= $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_pelanggan;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_order_user',$this->data);
			}
		}
	}

	function tambahProduk(){
		if(!$this->session->userdata('idu')){
			redirect('masuk');
		}else{
			if($this->session->userdata('status') == 'penjual'){
				$this->data['user'] = $this->Model_usr->getDetail('id_penjual','penjual',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_penjual;
				$this->data['foto'] 	= $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_penjual;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_tambah_produk_user',$this->data);
			}else{
				$this->data['user'] = $this->Model_usr->getDetail('id_pelanggan','pelanggan',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_pelanggan;
				$this->data['foto'] 	= $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_pelanggan;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_tambah_produk_user',$this->data);
			}
		}
	}

	function prosestambahproduk(){
		if(!is_numeric($this->input->post('harga'))){
			$this->session->set_flashdata('err','<div class="alert alert-danger"><b>Maaf,</b> harga harus angka. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
			redirect('akun/tambahProduk');
		}else{

			$config['upload_path'] = './produk/';
			$config['allowed_types'] = 'gif|jpg|png|jpeg';
			$config['max_size']	= '10000'; // max 10 MB
			$config['max_width']  = '6000';
			$config['max_height']  = '6000';

			$this->load->library('upload', $config);

			if ( ! $this->upload->do_upload())
			{
				$error = array('error' => $this->upload->display_errors());
				$this->session->set_flashdata('notif-error','<script> alert("gagal"); </script>');
				redirect('akun/tambahProduk');
			}
			else
			{
				$this->db->select_max('id_produk', 'atas');
				$max = $this->db->get('produk')->row();
				$max1 = $max->atas;
				$max2 = substr($max1, 3,4);
				$max3 = $max2 + 1;
				$max4 = "PRK".sprintf("%04s",$max3);

				$img = $this->upload->data();
				$data = array('id_produk' => $max4,
					'nama_produk' => ucwords($this->input->post('nama',true)),
				'gambar_produk' => $img['file_name'],
				'jenis_produk' => $this->input->post('jenis',true),
				'deskripsi' => $this->input->post('area2',true),
				'stock' => $this->input->post('stock',true),
				'harga' => $this->input->post('harga',true),
				'status' => 'menunggu',
				'id_penjual' => $this->session->userdata('idu'));
				$this->Model_usr->inputData('produk',$data);
				$this->session->set_flashdata('oke','<div class="alert alert-success"><b>Selamat,</b> data berhasil disimpan. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
				redirect('akun/tambahProduk');
			}
		}
	}

	function hapusproduk($id=NULL){
		$this->Model_usr->deleteData('id_produk','produk',$id);
		redirect('akun/produkUser');
	}

	function hapuspemesanan($id=NULL){
		$this->Model_usr->deleteData('id_pemesanan','pemesanan',$id);
		$this->Model_usr->deleteData('id_pemesanan','detail_pemesanan',$id);
		redirect('akun/pemesanan');
	}

	function editproduk(){
		if(!$this->session->userdata('idu')){
			redirect('masuk');
		}else{
			if($this->session->userdata('status') == 'penjual'){
				$this->data['pro'] = $this->Model_adm->getDetail('id_produk','produk',$this->input->post('id',true));
				$this->data['user'] = $this->Model_usr->getDetail('id_penjual','penjual',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_penjual;
				$this->data['foto'] 	= $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_penjual;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_edit_produk_user',$this->data);
			}else{
				$this->data['pro'] = $this->Model_adm->getDetail('id_produk','produk',$this->input->post('id',true));
				$this->data['user'] = $this->Model_usr->getDetail('id_pelanggan','pelanggan',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_pelanggan;
				$this->data['foto'] 	= $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_pelanggan;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_edit_produk_user',$this->data);
			}
		}
	}

	function proseseditproduk(){
		$isi_gbr = $_FILES['userfile']['name'];
		if($isi_gbr != ""){
			$config['upload_path'] = './produk/';
			$config['allowed_types'] = 'gif|jpg|png|jpeg';
			$config['max_size']	= '10000'; // max 10 MB
			$config['max_width']  = '6000';
			$config['max_height']  = '6000';

			$this->load->library('upload', $config);

			if ( ! $this->upload->do_upload())
			{
				$error = array('error' => $this->upload->display_errors());
				$this->session->set_flashdata('notif-error','<script> alert("Gagal Edit"); </script>');
				redirect('akun/editproduk/'.$this->input->post('id',true));
			}
			else
			{
				$img = $this->upload->data();
				$data = array('nama_produk' => ucwords($this->input->post('nama',true)),
				'gambar_produk' => $img['file_name'],
				'jenis_produk' => $this->input->post('jenis',true),
				'deskripsi' => $this->input->post('area2',true),
				'stock' => $this->input->post('stock',true),
				'harga' => $this->input->post('harga',true),
				'id_penjual' => $this->session->userdata('idu'));
				$this->Model_usr->updateData('id_produk','produk',$data,$this->input->post('id',true));
				$this->session->set_flashdata('oke','<div class="alert alert-success"><b>Selamat,</b> data berhasil disimpan. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
				redirect('akun/produkUser/'.$this->input->post('id',true));
			}
		}else{
				$data = array('nama_produk' => ucwords($this->input->post('nama',true)),
				'gambar_produk' => $this->input->post('gambar',true),
				'jenis_produk' => $this->input->post('jenis',true),
				'deskripsi' => $this->input->post('area2',true),
				'stock' => $this->input->post('stock',true),
				'harga' => $this->input->post('harga',true),
				'id_penjual' => $this->session->userdata('idu'));
				$this->Model_usr->updateData('id_produk','produk',$data,$this->input->post('id',true));
				$this->session->set_flashdata('oke','<div class="alert alert-success"><b>Selamat,</b> data berhasil disimpan. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
				redirect('akun/produkUser/');
		}
	}

	function pemesanan(){
		if(!$this->session->userdata('idu')){
			redirect('masuk');
		}else{
			if($this->session->userdata('status') == 'penjual'){
				$this->data['user'] = $this->Model_usr->getDetail('id_penjual','penjual',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_penjual;
				$this->data['foto'] = $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_penjual;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_pemesanan',$this->data);
			}else{
				$this->data['produk'] = $this->Model_usr->getProdukUser('id_pelanggan','pemesanan',$this->session->userdata('idu'));
				$this->data['user'] = $this->Model_usr->getDetail('id_pelanggan','pelanggan',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_pelanggan;
				$this->data['foto'] = $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_pelanggan;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_pemesanan',$this->data);
			}
		}
	}

	function detailpemesanan($id=NULL){
		if(!$this->session->userdata('idu')){
			redirect('masuk');
		}else{
			if($this->session->userdata('status') == 'penjual'){
				$this->data['user'] = $this->Model_usr->getDetail('id_penjual','penjual',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_penjual;
				$this->data['foto'] = $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_penjual;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_detailpemesanan',$this->data);
			}else{
				$this->data['pesan'] = $this->Model_usr->getjoinDetailArray('id_pemesanan','detail_pemesanan',$id);
		
				$this->db->select_sum('harga');
				$this->data['sum'] = $this->db->get_where('detail_pemesanan',array('id_pemesanan' => $id))->row();

				$this->data['user'] = $this->Model_usr->getDetail('id_pelanggan','pelanggan',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_pelanggan;
				$this->data['foto'] = $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_pelanggan;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_detailpemesanan',$this->data);
			}
		}
	}

	function detaildatapemesanan($id=NULL){
		if(!$this->session->userdata('idu')){
			redirect('masuk');
		}else{
			if($this->session->userdata('status') == 'penjual'){
				$this->data['pesan'] = $this->Model_usr->getjoinDetailArrays('id_pemesanan','detail_pemesanan',$id,$this->session->userdata('idu'));
		
				$this->db->select_sum('harga');
				$this->data['sum'] = $this->db->get_where('detail_pemesanan',array('id_pemesanan' => $id, 'id_penjual' => $this->session->userdata('idu')))->row();
				
				$this->data['user'] = $this->Model_usr->getDetail('id_penjual','penjual',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_penjual;
				$this->data['foto'] = $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_penjual;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_detaildatapemesanan',$this->data);
			}else{
				$this->data['user'] = $this->Model_usr->getDetail('id_pelanggan','pelanggan',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_pelanggan;
				$this->data['foto'] = $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_pelanggan;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_detaildatapemesanan',$this->data);
			}
		}
	}

	function updatedetail($id=NULL,$idp=NULL){
		$data = array('status_pengiriman' => 'sudah dikirim', 'no_resi' => $this->input->post('resi',true));
		$this->Model_usr->updateData('no','detail_pemesanan',$data,$id);
		redirect('akun/detaildatapemesanan/'.$idp);
	}

	function laporanJual(){
		if(!$this->session->userdata('idu')){
			redirect('masuk');
		}else{
			if($this->session->userdata('status') == 'penjual'){
				if($this->input->post('tgl1',true) != ''){
					$tanggal = array('tanggal_awal' => $this->input->post('tgl1',true),
									'tanggal_akhir' => $this->input->post('tgl2',true));
					$this->session->set_userdata($tanggal);

					$this->data['sum'] = $this->Model_usr->jumlah('detail_pemesanan',$this->input->post('tgl1',true),$this->input->post('tgl2',true),$this->session->userdata('idu'));
					$this->data['jual'] = $this->Model_usr->getBetweenn('detail_pemesanan',$this->input->post('tgl1',true),$this->input->post('tgl2',true),$this->session->userdata('idu'));
				}else{
					$this->db->select_sum('harga');
					$this->data['sum'] = $this->db->get_where('detail_pemesanan',array('id_penjual' => $this->session->userdata('idu'), 'status_pengiriman' => 'sudah dikirim'))->row();
					$this->session->unset_userdata('tanggal_akhir');
					$this->session->unset_userdata('tanggal_awal');
					$this->data['jual'] = $this->Model_usr->getjoinDetailss('detail_pemesanan',$this->session->userdata('idu'));
				}
				$this->data['user'] = $this->Model_usr->getDetail('id_penjual','penjual',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_penjual;
				$this->data['foto'] = $this->data['user']->foto;
				$this->load->view('v_laporanjual',$this->data);
			}else{
				$this->data['produk'] = $this->Model_usr->getProdukUser('id_pelanggan','pemesanan',$this->session->userdata('idu'));
				$this->data['user'] = $this->Model_usr->getDetail('id_pelanggan','pelanggan',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_pelanggan;
				$this->data['foto'] = $this->data['user']->foto;
				$this->load->view('v_laporanjual',$this->data);
			}
		}
	}

	function cetakLaporan($download_pdf =''){
		$ret = '';
		$id = 1;
		$pdf_filename = 'penjualan'.$id.'.pdf';
		if($this->session->userdata('tanggal_awal')){
			
					$sum = $this->Model_usr->jumlah('detail_pemesanan',$this->session->userdata('tanggal_awal'),$this->session->userdata('tanggal_akhir'),$this->session->userdata('idu'));
					$info = $this->Model_usr->getBetweenn('detail_pemesanan',$this->session->userdata('tanggal_awal'),$this->session->userdata('tanggal_akhir'),$this->session->userdata('idu'));
		}else{
			$this->db->select_sum('harga');
					$sum = $this->db->get_where('detail_pemesanan',array('id_penjual' => $this->session->userdata('idu'), 'status_pengiriman' => 'sudah dikirim'))->row();
					$info = $this->Model_usr->getjoinDetailss('detail_pemesanan',$this->session->userdata('idu'));
		}

		$halaman = array(
			'sum' => $sum,
			'pesan' => $info,
			'tgl1' => $this->session->userdata('tanggal_awal'),
			'tgl2' => $this->session->userdata('tanggal_akhir'));

		$file = $this->load->view('cetak_laporan',$halaman, true);

		$output = $file;

		if($download_pdf == TRUE){
			generate_pdf($output,$pdf_filename);
		}else{
			echo $output;
		}
	}
}