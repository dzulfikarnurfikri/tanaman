<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Artikel extends CI_Controller {

	public function index()
	{
		$this->data['art'] = $this->Model_usr->getData('artikel');
		$this->load->view('v_artikels',$this->data);
	}

	function detail($id=0){
		$this->data['art'] = $this->Model_usr->getData('artikel');
		$this->data['detail'] = $this->Model_usr->getDetail('id_artikel','artikel',$id);
		$this->load->view('v_detail_artikel',$this->data);
	}
}