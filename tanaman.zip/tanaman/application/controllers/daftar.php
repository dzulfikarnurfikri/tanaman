<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Daftar extends CI_Controller {

	public function index()
	{
		$this->load->view('v_daftar');
	}

	function prosespelanggan(){
		$nama 	= ucwords($this->input->post('nama',true));
		$telp 	= $this->input->post('telp',true);
		$email 	= $this->input->post('email',true);
		$pass1 	= $this->input->post('pass1',true);
		$pass2 	= $this->input->post('pass2',true);
		$cek 	= $this->db->get_where('pelanggan', array('email' => $email))->row();
		$ttlpass = strlen($pass1);
		$ttltelp = strlen($telp);

		$this->db->select_max('id_pelanggan', 'atas');
		$max = $this->db->get('pelanggan')->row();
		$max1 = $max->atas;
		$max2 = substr($max1, 4,3);
		$max3 = $max2 + 1;
		$max4 = "PLGN".sprintf("%03s",$max3);

		if(!is_numeric($telp)){
			$this->session->set_flashdata('err_telp','<div class="alert alert-danger"><b>Maaf,</b> Nomor telepon harus angka. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
				redirect('daftar');
		}elseif(count($cek) > 0){
			$this->session->set_flashdata('err_email','<div class="alert alert-danger"><b>Maaf,</b> Email telah digunakan. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
				redirect('daftar');
		}elseif($ttltelp < 10){
			$this->session->set_flashdata('err_passlen','<div class="alert alert-danger"><b>Maaf,</b> telepon harus 10 - 13 karakter. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
				redirect('daftar');
		}elseif($ttlpass < 6){
			$this->session->set_flashdata('err_passlen','<div class="alert alert-danger"><b>Maaf,</b> Password minimal 6 karakter. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
				redirect('daftar');
		}elseif($pass2 != $pass1){
			$this->session->set_flashdata('err_pass','<div class="alert alert-danger"><b>Maaf,</b> Password tidak sesuai. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
				redirect('daftar');
		}else{
			$data 	= array('id_pelanggan' => $max4,
							'nama_pelanggan' => $nama,
							'telepon' => $telp,
							'email' => $email,
							'password' => $pass1,
							'level' => 'pelanggan',
							'foto' => 'akun.png',
							'tanggal_daftar' => date('Y-m-d'));
			$insert = $this->Model_usr->inputData('pelanggan',$data);

			if($insert > 0){
				$this->session->set_flashdata('notif_oke','<div class="alert alert-success"><b>Selamat,</b> Anda berhasil daftar sebagai pelanggan. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
				redirect('daftar');
			}
		}
	}

	function prosespenjual(){
		$nama 	= ucwords($this->input->post('nama',true));
		$toko 	= ucwords($this->input->post('toko',true));
		$telp 	= $this->input->post('telp',true);
		$email 	= $this->input->post('email',true);
		$pass1 	= $this->input->post('pass1',true);
		$pass2 	= $this->input->post('pass2',true);
		$cek 	= $this->db->get_where('penjual', array('email' => $email))->row();
		$ttlpass = strlen($pass1);
		$ttltelp = strlen($telp);

		$this->db->select_max('id_penjual', 'atas');
		$max = $this->db->get('penjual')->row();
		$max1 = $max->atas;
		$max2 = substr($max1, 3,4);
		$max3 = $max2 + 1;
		$max4 = "PNJ".sprintf("%04s",$max3);

		if(!is_numeric($telp)){
			$this->session->set_flashdata('err_telp2','<div class="alert alert-danger"><b>Maaf,</b> Nomor telepon harus angka. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
				redirect('daftar');
		}elseif(count($cek) > 0){
			$this->session->set_flashdata('err_email2','<div class="alert alert-danger"><b>Maaf,</b> Email telah digunakan. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
				redirect('daftar');
		}elseif($ttltelp < 10){
			$this->session->set_flashdata('err_passlen2','<div class="alert alert-danger"><b>Maaf,</b> telepon harus 10 - 13 karakter. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
				redirect('daftar');
		}elseif($ttlpass < 6){
			$this->session->set_flashdata('err_passlen2','<div class="alert alert-danger"><b>Maaf,</b> Password minimal 6 karakter. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
				redirect('daftar');
		}elseif($pass2 != $pass1){
			$this->session->set_flashdata('err_pass2','<div class="alert alert-danger"><b>Maaf,</b> Password tidak sesuai. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
				redirect('daftar');
		}else{
			$data 	= array('id_penjual' => $max4,
							'toko' => $toko,
							'nama_penjual' => $nama,
							'telepon' => $telp,
							'email' => $email,
							'password' => $pass1,
							'level' => 'penjual',
							'foto' => 'akun.png',
							'tanggal_daftar' => date('Y-m-d'));
			$insert = $this->Model_usr->inputData('penjual',$data);

			if($insert > 0){
				$this->session->set_flashdata('notif_oke2','<div class="alert alert-success"><b>Selamat,</b> Anda berhasil daftar sebagai Penjual. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
				redirect('daftar');
			}
		}
	}
}