<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$txt = $this->input->post('txt',true);
		if($txt != ''){
			$this->data['produk'] = $this->Model_usr->getSearch('nama_produk','produk',$txt);
		}else{
			$this->data['produk'] = $this->Model_usr->getWhereData('produk');
		}
		$this->load->view('v_home',$this->data);
	}

	function kategori($id=NULL){
		if($this->input->post('txt',true) != ''){
			$this->data['produk'] = $this->Model_usr->getSearch('jenis_produk','produk',$this->input->post('txt',true));
		}else{
			$this->data['produk'] = $this->Model_usr->getSearch('jenis_produk','produk',$id);
		}
		$this->load->view('v_home',$this->data);
	}

	function harga($id=NULL){
		$hrg1 = $this->input->post('hrg1',true);
		$hrg2 = $this->input->post('hrg2',true);
		$this->data['produk'] = $this->Model_usr->getBetween('produk',$hrg1,$hrg2);
		$this->load->view('v_home',$this->data);
	}

	function detail($id){
		$this->data['detail'] = $this->Model_usr->getjoinDetailSatu('id_produk','produk',$id);
		$this->load->view('v_detail',$this->data);
	}

	function tentang(){
		$this->load->view('v_tentang');
	}

	function prosedur(){
		$this->load->view('v_prosedur');
	}

	function jualan(){
		$this->load->view('v_prosedurjualan');
	}
}