<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Keranjang extends CI_Controller {

	public function index()
	{
		$lihat = $this->cart->contents();
		$this->load->view('v_keranjang');
	}

	public function tambah($id)
	{
		$cek = $this->db->get_where('produk',array('id_produk' => $id))->row();
		$jml = $cek->stock;
		$nama = $cek->nama_produk;
		if($this->input->post('jml',true) > $jml){
			$this->session->set_flashdata('alert',"<script>alert('Maaf, stock $nama tidak mencukupi')</script>");
			redirect('home/detail/'.$id);
		}else{
			$select = $this->Model_usr->cartProduk('produk',$id);
			$data = array('id' => $select->id_produk,'qty' => $this->input->post('jml',true),'price' => $select->harga,'name' => $select->nama_produk);
			$this->cart->insert($data);
			redirect('keranjang');
		}
	}

	function addCart($id)
	{
		$select = $this->produk_model->cartProduk('produk',$id);
		$data = array('id' => $select->id_produk,'qty' => 1,'price' => $select->harga,'name' => $select->kategori.' '.$select->merk.' '.$select->tipe);
		$this->cart->insert($data);
		redirect('home/index');
	}

	function detailKeranjang()
	{
		$lihat = $this->cart->contents();
		$this->load->view('v_keranjang');
	}

	function KosongkanCart()
	{
		$this->cart->destroy();
		redirect('keranjang');
	}

	function hapus($rowid)
	{
		$this->cart->update(array('rowid' => $rowid, 'qty' => 0));
		redirect('keranjang');
	}

	function update()
	{
		
		$i = 1;
		if(isset($_POST['submit'])){
			foreach($this->cart->contents() as $items){
				$cek = $this->db->get_where('produk',array('id_produk' => $items['id']))->row();
				$jml = $cek->stock;
				$nama = $cek->nama_produk;
				if($_POST['qty'.$i] > $jml){
					$this->session->set_flashdata('alert',"<script>alert('Maaf, stock $nama tidak mencukupi')</script>");
					redirect('keranjang');
				}else{
					$this->cart->update(array('rowid' => $items['rowid'],'qty' => $_POST['qty'.$i]));
					
				}$i++;
			}
			redirect('keranjang');
		}else{
			redirect('keranjang');
			}
		}

	function verifikasi(){
		$logged_in = $this->session->userdata('logged_in');
		if(empty($logged_in)){
			redirect('masuk');
		}else{
			$this->data['u'] = $this->Model_usr->getDetail('id_pelanggan','pelanggan',$this->session->userdata('idu'));
			$lihat = $this->cart->contents();
			$this->load->view('v_verifikasi_alamat',$this->data);
		}
	}

	function pemesanan(){
		if($this->cart->contents()){
			if(isset($_POST['simpan'])){
				if(!is_numeric($this->input->post('telp',true))){
					echo $this->session->set_flashdata('error','No Telepon harus angka!!!');
					redirect('keranjang/verifikasi');
				}else{
					$this->db->select_max('id_pemesanan', 'atas');
					$max = $this->db->get('pemesanan')->row();
					$max1 = $max->atas;
					$max2 = substr($max1, 3,4);
					$max3 = $max2 + 1;
					$max4 = "ORD".sprintf("%04s",$max3);

					$invoice = array('id_pemesanan' => $max4,
					'id_pelanggan' => $this->session->userdata('idu'),
					'nama_penerima' => $this->input->post('nama', true),
					'telepon_penerima' => $this->input->post('telp', true),
					'alamat_penerima' => $this->input->post('alamat', true),
					'status' => 'belum lunas',
					'tahap' => 'proses',
					'tanggal' => date('Y-m-d'));
					$this->Model_usr->inputData('pemesanan',$invoice);
					$id_invoice = $max4;

						foreach ($this->cart->contents() as $item) {
								$cek = $this->db->get_where('produk',array('id_produk' => $item['id']))->row();
								$jml = $cek->stock;
								$hsl = $jml - $item['qty'];
								$idp = $cek->id_penjual;

								$stk = array('stock' => $hsl);
								$this->Model_usr->updateData('id_produk','produk',$stk,$item['id']);

								$data = array('id_pemesanan' => $id_invoice,
											'id_produk' => $item['id'],
											'jumlah' => $item['qty'],
											'harga' => $item['price'],
											'id_penjual' => $idp,
											'no_resi' => '-');
								$this->Model_usr->inputData('detail_pemesanan',$data);
						}
						$this->cart->destroy();
						$info = array('id' => $id_invoice);
						$this->load->view('v_pemesanan_sukses',$info);
				}
			}else{
				$logged_in = $this->session->userdata('logged_in');
				if(empty($logged_in)){
					redirect('home/masuk');
				}else{
					$this->load->view('v_verifikasi_alamat');
				}
			}
		}else{
			redirect('keranjang/detailKeranjang');
		}
	}

	function proseskonfirmasi(){
		if(!is_numeric($this->input->post('total',true))){
			$this->session->set_flashdata('error','<script> alert("Total pembayaran harus angka!"); </script>');
			redirect('keranjang/konfirmasi');
		}else{
			$config['upload_path'] = './bukti_bayar/';
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']	= '10000';
			$config['max_width']  = '10240';
			$config['max_height']  = '7680';

			$this->load->library('upload', $config);
			$this->upload->do_upload();
			$gambar = $this->upload->data();

			$this->db->select_max('id_pembayaran', 'atas');
					$max = $this->db->get('pembayaran')->row();
					$max1 = $max->atas;
					$max2 = substr($max1, 3,5);
					$max3 = $max2 + 1;
					$max4 = "KBB".sprintf("%05s",$max3);

			$data = array('id_pembayaran' => $max4,
				'id_pemesanan' => $this->input->post('kode', true),
					'total_pembayaran' => $this->input->post('total', true),
					'file' => $gambar['file_name'],
					'tanggal_pembayaran' => date('Y-m-d'));
			
			$this->Model_usr->inputData('pembayaran',$data);
			$this->load->view('v_pembayaran_sukses');
		}
	}

	function konfirmasi(){
		if(!$this->session->userdata('idu')){
			redirect('masuk');
		}else{
			if($this->session->userdata('status') == 'penjual'){
				$this->data['user'] = $this->Model_usr->getDetail('id_penjual','penjual',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_penjual;
				$this->data['foto'] 	= $this->data['user']->foto;
				$this->data['nama']	= $this->data['user']->nama_penjual;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_konfirmasi',$this->data);
			}else{
				$this->data['user'] = $this->Model_usr->getDetail('id_pelanggan','pelanggan',$this->session->userdata('idu'));
				$this->data['id'] 	= $this->data['user']->id_pelanggan;
				$this->data['nama']	= $this->data['user']->nama_pelanggan;
				$this->data['foto'] 	= $this->data['user']->foto;
				$this->data['email']	= $this->data['user']->email;
				$this->data['password']	= $this->data['user']->password;
				$this->data['alamat']	= $this->data['user']->alamat;
				$this->data['jk']	= $this->data['user']->jenis_kelamin;
				$this->data['tgl']	= $this->data['user']->tanggal_lahir;
				$this->data['bln']	= $this->data['user']->bulan_lahir;
				$this->data['thn']	= $this->data['user']->tahun_lahir;
				$this->data['telp']	= $this->data['user']->telepon;
				$this->load->view('v_konfirmasi',$this->data);
			}
		}
	}
}