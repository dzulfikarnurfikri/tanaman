<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Masuk extends CI_Controller {

	public function index()
	{
		$this->load->view('v_masuk');
	}

	function prosesmasuk(){
		$mail 	= $this->input->post('email',true);
		$pass 	= $this->input->post('pass',true);
		$akses 	= $this->input->post('akses',true);
		$cpass 	= strlen($pass);
		if($cpass < 6){
			$this->session->set_flashdata('err_masuk','<div class="alert alert-danger"><b>Maaf,</b> password minimal 6 angka. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
			redirect('masuk');
		}else{
			if($akses == 'pelanggan'){
				$cek 	= $this->Model_usr->cekloginpelanggan($mail,$pass,$akses);
				$nama 	= $cek->nama_pelanggan;
				$id 	= $cek->id_pelanggan;
				$status = $cek->level;
				if(count($cek) > 0){
					$data = array('logged_in' => true,
							'nama' => $nama,
							'idu' => $id,
							'status' => $status);
					$this->session->set_userdata($data);
					redirect('home');
				}else{
					$this->session->set_flashdata('err_masuk','<div class="alert alert-danger"><b>Maaf,</b> Anda belum terdaftar <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
					redirect('masuk');
				}
			}else{
				$cek 	= $this->Model_usr->cekloginpenjual($mail,$pass,$akses);
				$nama 	= $cek->nama_penjual;
				$id 	= $cek->id_penjual;
				$status = $cek->level;
				if(count($cek) > 0){
					$data = array('logged_in' => true,
							'nama' => $nama,
							'idu' => $id,
							'status' => $status);
					$this->session->set_userdata($data);
					redirect('home');
				}else{
					$this->session->set_flashdata('err_masuk','<div class="alert alert-danger"><b>Maaf,</b> Anda belum terdaftar <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
					redirect('masuk');
				}
			}

			
		}
	}

	function keluar(){
		$this->session->sess_destroy();
		redirect('home');
	}
}