<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_adm extends CI_Model {

	public function ceklogin($nip,$pass)
	{
		$this->db->where('email',$nip);
		$this->db->where('password',$pass);
		$query = $this->db->get('admin')->row();
		return $query;
	}

	function getData($table, $query=NULL){
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getDetail($select,$table, $id){
		$this->db->where($select,$id);
		$data = $this->db->get($table);
		return $data->row();
	}

	function getSearch($select,$table, $id){
		$this->db->like($select,$id);
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function inputData($table,$data){
		$insert = $this->db->insert($table,$data);
		return $insert;
	}

	function updateData($select,$table,$data,$id){
		$this->db->where($select,$id);
		$update = $this->db->update($table,$data);
		return $update;
	}

	function deleteData($select,$table,$id){
		$this->db->where($select,$id);
		$delete = $this->db->delete($table);
		return $delete;
	}

	function getjoinData($table){
		$this->db->join('karyawan', 'karyawan.nip = kerja_weekend.nip');
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getjoinSatu($table){
		$this->db->join('karyawan', 'karyawan.nip = cuti.nip');
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getjoinDetail($select,$table,$id){
		$this->db->where($select,$id);
		$this->db->join('penyakit', 'penyakit.id_penyakit = relasi_penyakit_gejala.id_penyakit');
		$this->db->join('gejala', 'gejala.id_gejala = relasi_penyakit_gejala.id_gejala');
		$data = $this->db->get($table);
		return $data->row();
	}

	function getjoinDetailSatu($select,$table,$id){
		$this->db->where($select,$id);
		$this->db->join('penjual', 'penjual.id_penjual = produk.id_penjual');
		$data = $this->db->get($table);
		return $data->row();
	}

	function getjoinDetailDua($select,$table,$id){
		$this->db->where($select,$id);
		$this->db->join('karyawan', 'karyawan.nip = kerja_weekend.nip');
		$data = $this->db->get($table);
		return $data->row();
	}

	function getjoinDetailArray($select,$table,$id){
		$this->db->where($select,$id);
		$this->db->join('karyawan', 'karyawan.nip = cuti.nip');
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getDetailArray($select,$table,$id){
		$this->db->where($select,$id);
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getDetailArrays($select,$table,$id){
		$this->db->where($select,$id);
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getDokumen($table,$id){
		$this->db->where('id_pelamar',$id);
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getBetween($table, $tgl1, $tgl2){
		$this->db->where('tanggal >=',$tgl1);
		$this->db->where('tanggal <=',$tgl2);
		$this->db->where('status','lunas');
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getBetweens($table, $tgl1, $tgl2){
		$this->db->where('tanggal_daftar >=',$tgl1);
		$this->db->where('tanggal_daftar <=',$tgl2);
		$data = $this->db->get($table);
		return $data->result_array();
	}
}