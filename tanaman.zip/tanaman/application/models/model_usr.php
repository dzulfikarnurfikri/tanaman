<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_usr extends CI_Model {

	public function cekloginpelanggan($mail,$pass,$akses)
	{
		$this->db->where('email',$mail);
		$this->db->where('password',$pass);
		$this->db->where('level',$akses);
		$query = $this->db->get('pelanggan')->row();
		return $query;
	}

	function cekloginpenjual($mail,$pass,$akses){
		$this->db->where('email',$mail);
		$this->db->where('password',$pass);
		$this->db->where('level',$akses);
		$query = $this->db->get('penjual')->row();
		return $query;
	}

	function getData($table, $query=NULL){
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getWhereData($table){
		$this->db->where('status','publish');
		$data = $this->db->get($table);
		return $data->result_array();
	}

	 function cartProduk($table,$id){
		$this->db->where('id_produk',$id);
		$select = $this->db->get($table);
		return $select->row();
	}

	function getDetail($select,$table, $id){
		$this->db->where($select,$id);
		$data = $this->db->get($table);
		return $data->row();
	}

	function getSearch($select,$table, $id){
		$this->db->like($select,$id);
		$this->db->where('status','publish');
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getBetween($table, $hrg1, $hrg2){
		$this->db->where('harga >=',$hrg1);
		$this->db->where('harga <=',$hrg2);
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function inputData($table,$data){
		$insert = $this->db->insert($table,$data);
		return $insert;
	}

	function updateData($select,$table,$data,$id){
		$this->db->where($select,$id);
		$update = $this->db->update($table,$data);
		return $update;
	}

	function deleteData($select,$table,$id){
		$this->db->where($select,$id);
		$delete = $this->db->delete($table);
		return $delete;
	}

	function getjoinData($table){
		$this->db->join('karyawan', 'karyawan.nip = kerja_weekend.nip');
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getjoinSatu($table){
		$this->db->join('penjual', 'penjual.id_penjual = produk.id_penjual');
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getjoinDetail($select,$table,$id){
		$this->db->where($select,$id);
		$this->db->join('penyakit', 'penyakit.id_penyakit = relasi_penyakit_gejala.id_penyakit');
		$this->db->join('gejala', 'gejala.id_gejala = relasi_penyakit_gejala.id_gejala');
		$data = $this->db->get($table);
		return $data->row();
	}

	function getjoinDetailSatu($select,$table,$id){
		$this->db->where($select,$id);
		$this->db->join('penjual', 'penjual.id_penjual = produk.id_penjual');
		$data = $this->db->get($table);
		return $data->row();
	}

	function getjoinDetailDua($select,$table,$id){
		$this->db->where($select,$id);
		$this->db->join('karyawan', 'karyawan.nip = kerja_weekend.nip');
		$data = $this->db->get($table);
		return $data->row();
	}

	function getProdukUser($select,$table,$id){
		$this->db->where($select,$id);
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getjoinDetailArray($select,$table,$id){
		$this->db->where($select,$id);
		$this->db->join('produk', 'produk.id_produk = detail_pemesanan.id_produk');
		$this->db->join('penjual', 'penjual.id_penjual = detail_pemesanan.id_penjual');
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getjoinDetailArrays($select,$table,$id,$idp){
		$this->db->where('detail_pemesanan.id_penjual',$idp);
		$this->db->where($select,$id);
		$this->db->join('produk', 'produk.id_produk = detail_pemesanan.id_produk');
		$this->db->join('penjual', 'penjual.id_penjual = detail_pemesanan.id_penjual');
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getDokumen($table,$id){
		$this->db->where('id_pelamar',$id);
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function jumlah($table, $tgl1, $tgl2, $id){
		$this->db->where('pemesanan.tanggal >=',$tgl1);
		$this->db->where('pemesanan.tanggal <=',$tgl2);
		$this->db->where('detail_pemesanan.id_penjual', $id);
		$this->db->where('detail_pemesanan.status_pengiriman','sudah dikirim');
		$this->db->join('produk', 'produk.id_produk = detail_pemesanan.id_produk');
		$this->db->join('pemesanan', 'pemesanan.id_pemesanan = detail_pemesanan.id_pemesanan');
		$this->db->select_sum('detail_pemesanan.harga');
		$data = $this->db->get($table);
		return $data->row();
	}

	function getBetweenn($table, $tgl1, $tgl2, $id){
		$this->db->where('pemesanan.tanggal >=',$tgl1);
		$this->db->where('pemesanan.tanggal <=',$tgl2);
		$this->db->where('detail_pemesanan.id_penjual', $id);
		$this->db->where('detail_pemesanan.status_pengiriman','sudah dikirim');
		$this->db->join('produk', 'produk.id_produk = detail_pemesanan.id_produk');
		$this->db->join('pemesanan', 'pemesanan.id_pemesanan = detail_pemesanan.id_pemesanan');
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getBetweens($table, $tgl1, $tgl2){
		$this->db->where('tanggal_daftar >=',$tgl1);
		$this->db->where('tanggal_daftar <=',$tgl2);
		$data = $this->db->get($table);
		return $data->result_array();
	}

	function getjoinDetailss($table,$id){
		$this->db->where('detail_pemesanan.id_penjual',$id);
		$this->db->where('detail_pemesanan.status_pengiriman','sudah dikirim');
		$this->db->join('produk', 'produk.id_produk = detail_pemesanan.id_produk');
		$this->db->join('pemesanan', 'pemesanan.id_pemesanan = detail_pemesanan.id_pemesanan');
		$data = $this->db->get($table);
		return $data->result_array();
	}
}