<!DOCTYPE html>
<html>
<head>
	<title>Penjual</title>
	<style type="text/css">
	body {
		font-family: sans-serif;
		font-size: 12px;
	}
	#table2 {
		width: 100%;
		text-align: center;
	}
	.head {
		width:100%;
		height:100px;
		border-bottom:1px solid;
	}
	</style>
</head>
<body>
<div class="head">
	<table border="0" width="100%">
		<tr>
			<td width="10%"><img src="<?php echo base_url('images/camera.png') ?>" width="80px"></td>
			<td width="90%" align="center">
			<font style="font-size:24px;font-weight:bold;">Online Shop</font><br>
			<font style="font-size:18px;">Jl. Peninggaran Timur II RT.002/ RW.09 Kebayoran Lama Utara, Jakarta Selatan.</font></td>
		</tr>
	</table>
</div><br>
	<center>
		<font>
		Laporan data penjual<br>
		Periode : <?php echo $tgl1 ?> s/d <?php echo $tgl2 ?>
		</font>
	</center><br><br>
<table id="table2" border="1" cellspacing="0">
    <thead>
        <tr style="height:40px;">
             <th width="5%">No</th>
                  <th width="10%">Kode Penjual</th>
                  <th width="15%">Nama Toko</th>
                  <th width="15%">Nama Penjual</th>
                  <th width="15%">Telepon</th>
                  <th width="15%">Email</th>
                  <th width="15%">Alamat</th>
                  <th width="15%">Tanggal Daftar</th>
        </tr>
    </thead>
    <tbody>
	<?php 
    $no = 1;
    foreach ($penjual as $k) {
    ?>
    <tr>
        <td><?php echo $no++ ?></td>
                    <td><?php echo $k['id_penjual'] ?></td>
                    <td><?php echo $k['toko'] ?></td>
                   	<td><?php echo $k['nama_penjual'] ?></td>
                    <td><?php echo $k['telepon'] ?></td>
                    <td><?php echo $k['email'] ?></td>
                    <td align="left"><?php echo $k['alamat'] ?></td>
                    <td><?php echo $k['tanggal_daftar'] ?></td>
    </tr>
    <?php } ?>
	</tbody>
</table><br><br>
<?php 
	$date = mktime(date("m"),date("d"),date("Y"));
?>
<table border="0" width="100%">
	<tr>
		<td width="75%">&nbsp;</td>
		<td width="25%">
		Jakarta, <?php echo date("d M Y", $date); ?>
		<br><br><br>
		Pemilik Toko
		</td>
	</tr>
</table>
</body>
</html>