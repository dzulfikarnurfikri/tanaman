<!DOCTYPE html>
<html>
<head>
	<title>Penjualan</title>
	<style type="text/css">
	body {
		font-family: sans-serif;
		font-size: 12px;
	}
	#table2 {
		width: 100%;
		text-align: center;
	}
	.head {
		width:100%;
		height:100px;
		border-bottom:1px solid;
	}
	</style>
</head>
<body>
<div class="head">
	<table border="0" width="100%">
		<tr>
			<td width="10%"><img src="<?php echo base_url('images/camera.png') ?>" width="80px"></td>
			<td width="90%" align="center">
			<font style="font-size:24px;font-weight:bold;">Online Shop</font><br>
			<font style="font-size:18px;">Jl. Peninggaran Timur II RT.002/ RW.09 Kebayoran Lama Utara, Jakarta Selatan.</font></td>
		</tr>
	</table>
</div><br>
	<center>
		<font>
		Laporan data penjualan<br>
		Periode : <?php echo $tgl1 ?> s/d <?php echo $tgl2 ?>
		</font>
	</center><br><br>
<table id="table2" border="1" cellspacing="0">
    <thead>
        <tr style="height:40px;">
           <th width="5%">No</th>
                  <th width="10%">Kode Pemesanan</th>
                  <th width="10%">Nama penerima</th>
                  <th width="10%">Telepon</th>
                  <th width="20%">Alamat</th>
                  <th width="10%">Status</th>
                  <th width="7%">Tahap</th>
        </tr>
    </thead>
    <tbody>
	<?php 
    $no = 1;
    foreach ($pesan as $k) {
    ?>
    <tr>
        <td><?php echo $no++ ?></td>
                    <td><?php echo $k['id_pemesanan'] ?></td>
                    <td><?php echo $k['nama_penerima'] ?></td>
                    <td><?php echo $k['telepon_penerima'] ?></td>
                    <td><?php echo $k['alamat_penerima'] ?></td>
                    <td><?php echo $k['status'] ?></td>
                    <td><?php echo $k['tahap'] ?></td>
    </tr>
    <?php } ?>
	</tbody>
</table><br><br>
<?php 
	$date = mktime(date("m"),date("d"),date("Y"));
?>
<table border="0" width="100%">
	<tr>
		<td width="75%">&nbsp;</td>
		<td width="25%">
		Jakarta, <?php echo date("d M Y", $date); ?>
		<br><br><br>
		Pemilik Toko
		</td>
	</tr>
</table>
</body>
</html>