<!DOCTYPE html>
<html>
<head>
	<title>Produk</title>
	<style type="text/css">
	body {
		font-family: sans-serif;
		font-size: 12px;
	}
	#table2 {
		width: 100%;
		text-align: center;
	}
	.head {
		width:100%;
		height:100px;
		border-bottom:1px solid;
	}
	</style>
</head>
<body>
<div class="head">
	<table border="0" width="100%">
		<tr>
			<td width="10%"><img src="<?php echo base_url('images/camera.png') ?>" width="80px"></td>
			<td width="90%" align="center">
			<font style="font-size:24px;font-weight:bold;">Online Shop</font><br>
			<font style="font-size:18px;">Jl. Peninggaran Timur II RT.002/ RW.09 Kebayoran Lama Utara, Jakarta Selatan.</font></td>
		</tr>
	</table>
</div><br>
	<center>
		<font style="font-size:20px;">
		Laporan data produk
		</font>
	</center><br><br>
<table id="table2" border="1" cellspacing="0">
    <thead>
        <tr style="height:40px;">
            <th width="3%">No</th>
            <th width="25%">Nama</th>
            <th width="10%">Jenis</th>
            <th width="5%">Stock</th>
            <th width="10%">Harga</th>
            <th width="10%">Status</th>
        </tr>
    </thead>
    <tbody>
	<?php 
    $no = 1;
    foreach ($produk as $k) {
    ?>
    <tr>
        <td><?php echo $no++ ?></td>
        <td align="left" style="padding:0 4px;"><?php echo $k['nama_produk'] ?></td>
        <td align="left" style="padding:0 4px;"><?php echo $k['jenis_produk'] ?></td>
        <td><?php echo $k['stock'] ?></td>
        <td align="left" style="padding:0 4px;">Rp. <?php echo number_format($k['harga'],2,',','.') ?></td>
        <td><?php echo $k['status'] ?></td>
    </tr>
    <?php } ?>
	</tbody>
</table><br><br>
<?php 
	$date = mktime(date("m"),date("d"),date("Y"));
?>
<table border="0" width="100%">
	<tr>
		<td width="75%">&nbsp;</td>
		<td width="25%">
		Jakarta, <?php echo date("d M Y", $date); ?>
		<br><br><br>
		Pemilik Toko
		</td>
	</tr>
</table>
</body>
</html>