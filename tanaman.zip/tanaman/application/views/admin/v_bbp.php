<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Bukti Bayar Pemesanan | Administrator</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('datatables/dataTables.bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('admin/v_header') ?>
	<div class="container">
		<h3>Data Bukti Bayar Pesanan</h3>
		
			<div class="box">
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th width="5%">No</th>
                  <th width="15%">Kode Pemesanan</th>
                  <th width="15%">Total Pembayaran</th>
                  <th width="30%">File</th>
                  <th width="20%">Tanggal Pembayaran</th>
                  <?php if($this->session->userdata('status_admin') == 'admin'){ ?>
                  <th width="20%">Aksi</th>
                  <?php } ?>
                </tr>
                </thead>
                <tbody>

                  <?php 
                    $no = 1;
                    foreach ($bayar as $k) {
                  ?>
                  <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $k['id_pemesanan'] ?></td>
                    <td>Rp. <?php echo number_format($k['total_pembayaran'],2,',','.') ?></td>
                    <td> <a target="blank" href="<?php echo base_url('bukti_bayar/'.$k['file']) ?>"><img src="<?php echo base_url('bukti_bayar/'.$k['file']) ?>" width ="150px" height="100px"></a></td>
                    <td><?php echo $k['tanggal_pembayaran'] ?></td>
                    <?php if($this->session->userdata('status_admin') == 'admin'){ ?>
                    <td>
                    	<a href="<?php echo site_url('admin/lunas/'.$k['id_pemesanan']) ?>" onclick="return confirm('Yakin ingin pilih lunas ?')" class="btn btn-primary">Lunas</a>
                      <a href="<?php echo site_url('admin/hapusbayar/'.$k['id_pembayaran']) ?>" onclick="return confirm('Yakin ingin hapus ?')"><div class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</div></a>  
                    </td> 
                    <?php } ?>
                  </tr>
                 <?php } ?>
    
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>

	<?php $this->load->view('admin/v_footer') ?>
	</div>

	<script src="<?php echo base_url('datatables/jquery.dataTables.min.js') ?>"></script>
	<script src="<?php echo base_url('datatables/dataTables.bootstrap.min.js') ?>"></script>
	<script>
	  $(document).ready(function(){
	    $(function () {
	      $("#example1").DataTable();
	      $('#example2').DataTable({
	        "paging": true,
	        "lengthChange": false,
	        "searching": false,
	        "ordering": true,
	        "info": true,
	        "autoWidth": false
	      });
	    });
	  });
	 </script>
</body>
</html>