<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Beranda Administrator</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('datatables/dataTables.bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('admin/v_header') ?>
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<img src="<?php echo base_url('images/admin.png') ?>">
			</div>

			<div class="col-md-4">
				<h3>Selamat Datang, <?php echo $this->session->userdata('nama_admin') ?></h3>
				<p>Pada halaman ini, Anda dapat mengelola data.</p>
			</div>
		</div>

	<?php $this->load->view('admin/v_footer') ?>
	</div>

	<script src="<?php echo base_url('datatables/jquery.dataTables.min.js') ?>"></script>
	<script src="<?php echo base_url('datatables/dataTables.bootstrap.min.js') ?>"></script>
	<script>
	  $(document).ready(function(){
	    $(function () {
	      $("#example1").DataTable();
	      $('#example2').DataTable({
	        "paging": true,
	        "lengthChange": false,
	        "searching": false,
	        "ordering": true,
	        "info": true,
	        "autoWidth": false
	      });
	    });
	  });
	 </script>
</body>
</html>