<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Data pemesanan | Administrator</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('datatables/dataTables.bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('admin/v_header') ?>
	<div class="container">
		<h3>Data Pemesanan</h3>
      <a target="blank" href="<?php echo site_url('admin/cetakInvoice/'.$id.'/true') ?>" class="btn btn-primary">Cetak</a>
      <a href="<?php echo site_url('admin/pemesanan') ?>" class="btn btn-success">Kembali</a><br><br>
        
      <div class="box">
            <div class="box-body">
              <table class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th width="5%">No</th>
                  <th width="13%">Kode pemesanan</th>
                  <th width="15%">Toko</th>
                  <th width="25%">Nama produk</th>
                  <th width="10%">Status</th>
                  <th width="15%">No Resi</th>
                  <th width="5%">Kuantiti</th>
                  <th width="20%">Harga</th>
                </tr>
                </thead>
                <tbody>

                  <?php 
                    $no = 1;
                    foreach ($pesan as $k) {
                  ?>
                  <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $k['id_pemesanan'] ?></td>
                    <td><?php echo $k['toko'] ?></td>
                    <td><?php echo $k['nama_produk'] ?></td>
                    <td><?php echo $k['status_pengiriman'] ?></td>
                    <td><?php echo $k['no_resi'] ?></td>
                    <td><?php echo $k['jumlah'] ?></td>
                    <td>Rp. <?php echo number_format($k['harga'],2,',','.') ?></td>
                  </tr>
                 <?php } ?>
                  <tr>
                    <td colspan="7"><strong>Total</strong></td>
                    <td>Rp. <?php echo number_format($sum->harga,2,',','.') ?></td>
                  </tr>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>

	<?php $this->load->view('admin/v_footer') ?>
	</div>

	<script src="<?php echo base_url('datatables/jquery.dataTables.min.js') ?>"></script>
	<script src="<?php echo base_url('datatables/dataTables.bootstrap.min.js') ?>"></script>
	<script>
	  $(document).ready(function(){
	    $(function () {
	      $("#example1").DataTable();
	      $('#example2').DataTable({
	        "paging": true,
	        "lengthChange": false,
	        "searching": false,
	        "ordering": true,
	        "info": true,
	        "autoWidth": false
	      });
	    });
	  });
	 </script>
</body>
</html>