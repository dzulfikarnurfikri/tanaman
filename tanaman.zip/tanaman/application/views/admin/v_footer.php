<nav class="navbar navbar-default">
	<div class="container-fluid" style="line-height:50px;">
		<center>
			Copyright &copy; 2017 Dzulfikar Nurfikri. All Rights Reserved.</font>
		</center>
	</div>
</nav>