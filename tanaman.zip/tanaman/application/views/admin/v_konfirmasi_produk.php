<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Konfirmasi Produk | Administrator</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('datatables/dataTables.bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
  <script type="text/javascript" src="<?php echo base_url('nicEdit.js') ?>"></script>
  <script type="text/javascript">
    bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
  </script>
</head>
<body>
	<?php $this->load->view('admin/v_header') ?>
	<div class="container">
    <?php
    echo $this->session->flashdata('notif-oke');
    echo $this->session->flashdata('notif-error');
    ?>
		<h3>Konfirmasi Produk</h3>
		<a href="<?php echo site_url('admin/produk') ?>" class="btn btn-success"> Browse</a><br><br>
		<?php if($produk){ ?>

		<div class="row">
			<div class="col-md-6">
				<font style="font-size:19px;font-weight:bold;">Data Produk</font>
				<table border="0" width="100%">
					<tr style="height:40px;">
							<td width="25%">Nama Produk</td> <td width="75%">: <?php echo $produk->nama_produk ?></td>
						</tr>
						<tr style="height:40px;">
							<td>Jenis Porduk</td> <td>: <?php echo $produk->jenis_produk ?></td>
						</tr>
						<tr style="height:40px;">
							<td>Harga Produk</td> <td>: Rp. <?php echo number_format($produk->harga,2,',','.') ?></td>
						</tr>
						<tr style="height:40px;">
							<td>Stock Produk</td> <td>: <?php echo $produk->stock ?></td>
						</tr>
						<tr style="height:40px;">
							<td>Foto Produk</td> <td>: <img src="<?php echo base_url('produk/'.$produk->gambar_produk) ?>" width="200px" height="200px"></td>
						</tr>
						<tr style="height:40px;">
							<td>Deskripsi Produk</td> <td>: <?php echo $produk->deskripsi ?></td>
						</tr>	
				</table>
			</div>
			<div class="col-md-6">
				<font style="font-size:19px;font-weight:bold;">Data Penjual</font>
				<table border="0" width="100%">
					<tr style="height:40px;">
						<td width="25%">Kode User</td> <td width="75%">: <?php echo $produk->id_penjual ?></td>
					</tr>
					<tr style="height:40px;">
						<td>Nama Lengkap</td> <td>: <?php echo $produk->nama_penjual ?></td>
					</tr>
					<tr style="height:40px;">
						<td>Tanggal Lahir</td> <td>: <?php echo $produk->tanggal_lahir ?></td>
					</tr>
					<tr style="height:40px;">
						<td>Jenis Kelamin</td> <td>: <?php echo $produk->jenis_kelamin ?></td>
					</tr>
					<tr style="height:40px;">
						<td>Telepon</td> <td>: <?php echo $produk->telepon ?></td>
					</tr>
					<tr style="height:40px;">
						<td>Email</td> <td>: <?php echo $produk->email ?></td>
					</tr>
					<tr style="height:40px;">
						<td>Alamat</td> <td>: <?php echo $produk->alamat ?></td>
					</tr>
				</table><br>
				<font style="font-size:19px;font-weight:bold;">Konfirmasi</font><br>
				<p>Klik publish di bawah ini, jika produk ini layak untuk ditampilkan.</p>
				<form action="<?php echo site_url('admin/proseskonfirm') ?>" method="post">
					<input type="hidden" name="id" value="<?php echo $produk->id_produk ?>">
					<input type="checkbox" name="stat" value="publish" required> Publish <br>
					<input type="submit" name="konfirm" class="btn btn-danger" value="Konfirmasi produk">
				</form><br>
			</div>
		</div>
		<?php } ?>
        

	<?php $this->load->view('admin/v_footer') ?>
	</div>

	<script src="<?php echo base_url('datatables/jquery.dataTables.min.js') ?>"></script>
	<script src="<?php echo base_url('datatables/dataTables.bootstrap.min.js') ?>"></script>
	<script>
	  $(document).ready(function(){
	    $(function () {
	      $("#example1").DataTable();
	      $('#example2').DataTable({
	        "paging": true,
	        "lengthChange": false,
	        "searching": false,
	        "ordering": true,
	        "info": true,
	        "autoWidth": false
	      });
	    });
	  });
	 </script>
</body>
</html>