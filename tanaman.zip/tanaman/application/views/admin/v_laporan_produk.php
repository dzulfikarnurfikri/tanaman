<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Produk | Administrator</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('datatables/dataTables.bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('admin/v_header') ?>
	<div class="container">
		<h3>Data Produk</h3>
		<a target="blank" href="<?php echo site_url('admin/cetakProduk/true') ?>" class="btn btn-primary">Cetak</a><br><br>
			<div class="box">
            <div class="box-body">
              <table class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th width="5%">No</th>
                  <th width="15%">Nama Produk</th>
                  <th width="15%">Jenis Produk</th>
                  <th width="20%">Gambar</th>
                  <th width="15%">Harga</th>
                  <th width="5%">Stock</th>
                  <th width="10%">Status</th>
                </tr>
                </thead>
                <tbody>

                  <?php 
                    $no = 1;
                    foreach ($produk as $k) {
                  ?>
                  <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $k['nama_produk'] ?></td>
                    <td><?php echo $k['jenis_produk'] ?></td>
                    <td> <img src="<?php echo base_url('produk/'.$k['gambar_produk']) ?>" width="100px" height="100px"> </td>
                   	<td>Rp. <?php echo number_format($k['harga'],2,',','.') ?></td>
                    <td><?php echo $k['stock'] ?></td>
                    <td><?php echo $k['status'] ?></td>
                    
                  </tr>
                 <?php } ?>
    
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>

	<?php $this->load->view('admin/v_footer') ?>
	</div>

	<script src="<?php echo base_url('datatables/jquery.dataTables.min.js') ?>"></script>
	<script src="<?php echo base_url('datatables/dataTables.bootstrap.min.js') ?>"></script>
	<script>
	  $(document).ready(function(){
	    $(function () {
	      $("#example1").DataTable();
	      $('#example2').DataTable({
	        "paging": true,
	        "lengthChange": false,
	        "searching": false,
	        "ordering": false,
	        "info": true,
	        "autoWidth": false
	      });
	    });
	  });
	 </script>
</body>
</html>