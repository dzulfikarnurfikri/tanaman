<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Login Administrator</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body style="background-color:#f9f9f9;">
<div class="container" style="width:30%;border:1px solid #999;padding:1%;margin-top:12%;background-color:#ffffff;">
	<center><font style="font-weight:bold;font-size:20px;">Login</font></center>
	<?php echo $this->session->flashdata('err') ?>
	<form action="<?php echo site_url('admin/proseslogin') ?>" method="post" />
	  <div class="form-group">
	    <label for="exampleInputEmail1">Email</label>
	    <input type="email" class="form-control" name="email" placeholder="Email" required />
	  </div>
	  <div class="form-group">
	    <label for="exampleInputPassword1">Password</label>
	    <input type="password" class="form-control" maxlength="10" name="pass" placeholder="Password" required />
	  </div>
	  <div class="checkbox">
	    <label>
	      <input type="checkbox"> Check me out
	    </label>
	  </div>
	  <button type="submit" name="login" class="btn btn-danger">Submit</button>
	</form>
</div>
</body>
</html>