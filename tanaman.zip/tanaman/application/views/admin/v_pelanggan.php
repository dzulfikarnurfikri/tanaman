<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Pelanggan | Administrator</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('datatables/dataTables.bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('admin/v_header') ?>
	<div class="container">
  Cari berdasarkan tanggal :
    <form action="<?php echo site_url('admin/pelanggan') ?>" method="POST">
      <input type="date" name="tgl1" />
      <input type="date" name="tgl2" />
      <input type="submit" name="tgl" value="Cari">
    </form>
		<h3>Data Pelanggan</h3>
		<a target="blank" href="<?php echo site_url('admin/cetakPelanggan/true') ?>" class="btn btn-primary">Cetak</a><br><br>
			<div class="box">
            <div class="box-body">
              <table class="table table-bordered table-striped" style="width:100%">
                <thead>
                <tr>
                  <th width="5%">No</th>
                  <th width="15%">Kode Pelanggan</th>
                  <th width="15%">Nama Pelanggan</th>
                  <th width="15%">Telepon</th>
                  <th width="15%">Email</th>
                  <th width="15%">Alamat</th>
                  <th width="15%">Tanggal Daftar</th>
                </tr>
                </thead>
                <tbody>

                  <?php 
                    $no = 1;
                    foreach ($pelanggan as $k) {
                  ?>
                  <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $k['id_pelanggan'] ?></td>
                    <td><?php echo $k['nama_pelanggan'] ?></td>
                    <td><?php echo $k['telepon'] ?></td>
                    <td><?php echo $k['email'] ?></td>
                    <td><?php echo $k['alamat'] ?></td>
                    <td><?php echo $k['tanggal_daftar'] ?></td>
                  </tr>
                 <?php } ?>
    
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>

	<?php $this->load->view('admin/v_footer') ?>
	</div>

	<script src="<?php echo base_url('datatables/jquery.dataTables.min.js') ?>"></script>
	<script src="<?php echo base_url('datatables/dataTables.bootstrap.min.js') ?>"></script>
	<script>
	  $(document).ready(function(){
	    $(function () {
	      $("#example1").DataTable();
	      $('#example2').DataTable({
	        "paging": true,
	        "lengthChange": false,
	        "searching": false,
	        "ordering": true,
	        "info": true,
	        "autoWidth": false
	      });
	    });
	  });
	 </script>
</body>
</html>