<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Tambah Artikel Tanaman Hias | Administrator</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap3-wysihtml5.min.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('datatables/dataTables.bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap3-wysihtml5.all.min.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('admin/v_header') ?>
	<div class="container">
    <?php
    echo $this->session->flashdata('notif-oke');
    echo $this->session->flashdata('notif-error');
    ?>
		<h3>Tambah Artikel Tanaman Hias</h3>
		<a href="<?php echo site_url('admin/artikel') ?>" class="btn btn-success"> Browse</a><br><br>
			<form action="<?php echo site_url('admin/prosestambahartikel') ?>" enctype="multipart/form-data" method="post">
        <div class="form-group">
          <label for="exampleInputEmail1">Judul</label>
          <input type="text" name="judul" class="form-control" placeholder="Judul Artikel"/>
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Artikel</label>
            <textarea name="area2" style="width:100%" rows="10"></textarea>
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">Gambar</label>
          <input type="file" name="userfile"/>
        </div>
        <button type="submit" class="btn btn-primary">Simpan Data</button>
      </form><br><br>

	<?php $this->load->view('admin/v_footer') ?>
	</div>

	<script src="<?php echo base_url('datatables/jquery.dataTables.min.js') ?>"></script>
	<script src="<?php echo base_url('datatables/dataTables.bootstrap.min.js') ?>"></script>
	<script>
	  $(document).ready(function(){
	    $(function () {
	      $("#example1").DataTable();
	      $('#example2').DataTable({
	        "paging": true,
	        "lengthChange": false,
	        "searching": false,
	        "ordering": true,
	        "info": true,
	        "autoWidth": false
	      });
	    });

	    $('.textarea').wysihtml5();
	  });
	 </script>
</body>
</html>