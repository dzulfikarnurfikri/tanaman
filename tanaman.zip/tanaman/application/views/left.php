<div class="container-fluid">
	<font style="font-weight:bold;">Cari di kategori ini</font>
		<form action="<?php echo site_url('home/kategori') ?>" method="post">
			<div class="input-group">
				<input type="text" name="txt" class="form-control" placeholder="Search for...">
				<span class="input-group-btn">
					<button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
				</span>
			</div>
		</form><br>
	<font style="font-weight:bold;">Harga</font>
		<form action="<?php echo site_url('home/harga') ?>" method="post">
			<div class="input-group">
			    <select name="hrg1">
			    	<option value="10000">Rp. 10.000</option>
			    	<option value="20000">Rp. 20.000</option>
			    	<option value="40000">Rp. 40.000</option>
			    	<option value="60000">Rp. 60.000</option>
			    	<option value="80000">Rp. 80.000</option>
			    	<option value="100000">Rp. 100.000</option>
			    </select>
			    ke
			    <select name="hrg2">
			    	<option value="10000">Rp. 10.000</option>
			    	<option value="20000">Rp. 20.000</option>
			    	<option value="40000">Rp. 40.000</option>
			    	<option value="60000">Rp. 60.000</option>
			    	<option value="80000">Rp. 80.000</option>
			    	<option value="100000">Rp. 100.000</option>
			    </select> 
			</div>
			<input type="submit" name="cari" value="Go!">
		</form><br>
	<font style="font-weight:bold;">Dukungan Pengiriman</font>
	<img src="<?php echo base_url('images/jne.png') ?>"><br><br>
	<font style="font-weight:bold;">Pembayaran bisa transfer ke</font><br>

	<div class="panel panel-danger">
		<div class="panel-heading">Rekening BCA</div>
		<div class="panel-body">
			123 - 123 – 1234 <br> a.n Fulan
		</div>
	</div>

	<div class="panel panel-info">
		<div class="panel-heading">Rekening BNI</div>
		<div class="panel-body">
			12- 1234 – 1234  <br> a.n Fulan
		</div>
	</div>

	<div class="panel panel-success">
		<div class="panel-heading">Rekening BRI</div>
		<div class="panel-body">
			1234 – 12345 – 123 – 123  <br> a.n Fulan
		</div>
	</div>

	<div class="panel panel-primary">
		<div class="panel-heading">Belanja online aman</div>
		<div class="panel-body">
			Setiap transaksi dijamin aman dari penipuan karena pembeli tidak mentransfer uang langsung ke penjual melainkan lewat Online shop.<hr>

			PEMASARAN<br>
			Hanya melayani transaksi di wilayah Jakarta.
		</div>
	</div>
</div>