<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Halaman Utama</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
	<style type="text/css">
	a {
		color: #fff;
	}
	</style>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > Akun saya</font> 
		</nav>
	</div>
	<div class="row">
		<div class="col-md-3">
			<img src="<?php echo base_url('foto/'.$foto) ?>" width="100%"><br><br>
		</div>
		<div class="col-md-9">
			<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
				<font style="color:#666;">
				<a href="<?php echo site_url('akun') ?>">Akun</a> | <a href="<?php echo site_url('akun/update/'.$id) ?>">Ubah akun</a> |
				<?php if($user->level == 'pelanggan'){ ?>
				<a href="<?php echo site_url('akun/pemesanan') ?>"> Pesanan saya </a> | 
				<a href="<?php echo site_url('keranjang/konfirmasi') ?>">Konfirmasi bayar pesanan</a>
				<?php }else{ ?>
				<a href="<?php echo site_url('akun/produkUser') ?>"> Produk saya </a> |
				<a href="<?php echo site_url('akun/orderUser') ?>"> Data pemesanan </a> |
				<a href="<?php echo site_url('akun/laporanJual') ?>"> Laporan penjualan </a>
				<?php } ?></font> 
			</nav>
			<?php echo $this->session->flashdata('notif_oke2') ?>
			<font style="font-size:18px;font-weight:bold;"><?php echo $nama ?></font><br>
			<table border="0" width="100%">
				<tr style="height:30px;border-bottom:1px solid #eee;">
					<td width="15%">Email</td><td width="85%">: <?php echo $email ?></td>
				</tr>
				<tr style="height:30px;border-bottom:1px solid #eee;">
					<td>Telepon</td><td>: <?php echo $telp ?></td>
				</tr>
				<tr style="height:30px;border-bottom:1px solid #eee;">
					<td>Tanggal Lahir</td><td>: <?php echo $tgl." ".$bln." ".$thn ?></td>
				</tr>
				<tr style="height:30px;border-bottom:1px solid #eee;">
					<td>Jenis Kelamin</td><td>: <?php echo $jk ?></td>
				</tr>
				<tr style="height:30px;border-bottom:1px solid #eee;">
					<td>Alamat</td><td>: <?php echo $alamat ?></td>
				</tr>
			</table>
		</div>
	</div>

	<?php $this->load->view('v_foot') ?>
</div>
</body>
</html>