<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Artikel</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > Artikel</font> 
		</nav>
	<?php if($art){ ?>
	<div class="row">
		<div class="col-md-9">
			 <h3>Artikel</h3>
				<?php foreach ($art as $k) { ?>
					<div class="panel">
					    <h2><?php echo $k['judul'] ?></h2>
			        <p><div class="glyphicon glyphicon-calendar"> </div> <?php echo $k['tanggal'] ?></p>
			        <div class="row">
			        	<div class="col-md-2">
			        		<img src="<?php echo base_url('artikelimg/'.$k['gambar']) ?>" width="100px" height="100px"/>
			        	</div>
			        	<div class="col-md-10">
			        		<?php echo substr($k['isi'], 0,400) ?>... <a href="<?php echo site_url('artikel/detail/'.$k['id_artikel']) ?>">Lihat selengkapnya &raquo;</a>	
			        	</div>
			        </div>
					</div>
			    <?php } ?>		  
		</div>
		<div class="col-md-3">
			<h3>Arsip</h3>
				<div class="panel">
					<div class="panel-body">
						<div class="list-group">
						<?php foreach ($art as $k) { ?>
						<a href="<?php echo site_url('artikel/detail/'.$k['id_artikel']) ?>" class="list-group-item"><?php echo $k['judul'] ?></a>
						<?php } ?>
						</div>
					</div>
				</div>
		</div>
	</div>
	<?php }else{ ?>
		<div class="alert alert-danger" role="alert">Tidak ada artikel</div>
	<?php } ?>

	<?php $this->load->view('v_foot') ?>
</div>
</body>
</html>