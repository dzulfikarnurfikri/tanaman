<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Daftar</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<div class="container" style="border:0px solid;margin-top:0px;">
	<div class="container-fluid">
		<center>
			<a href="<?php echo site_url() ?>"><h3>Online Shop</h3></a>
			<h4>DAFTAR DI ONLINE SHOP</h4>
			<P>Sudah punya akun Online Shop ? Masuk <a href="<?php echo site_url('masuk') ?>">di sini</a></P>
		</center>
	</div>

	<div class="row">
		<div class="col-md-6" style="border-right:1px solid #999;">
			<div class="container-fluid" style="width:70%;">
			
				<center><h4>Daftar sebagai Pelanggan</h4></center>
				<?php 
				echo $this->session->flashdata('notif_oke');
				echo $this->session->flashdata('err_telp');
				echo $this->session->flashdata('err_email');
				echo $this->session->flashdata('err_pass');
				echo $this->session->flashdata('err_passlen');
				?>
				<form action="<?php echo site_url('daftar/prosespelanggan') ?>" id="form-pelanggan" method="post">
					<div class="form-group">
			          <label>Nama Lengkap</label>
			          <input type="text" name="nama" class="form-control" placeholder="nama lengkap" required/>
			    
			        </div>
			        <div class="form-group">
			          <label>Nomor Telepon</label>
			          <input type="text" name="telp" class="form-control" maxlength="13" placeholder="nomor telepon" required/>
			          <span style="font-size:12px;">Masukkan nomor telepon yang valid, demi kenyamanan belanja dan transaksi anda.</span>
			        </div>
			        <div class="form-group">
			          <label>Email</label>
			          <input type="email" name="email" class="form-control" placeholder="email" required/>
		
			        </div>
			        <div class="form-group">
			          <label>Kata Sandi</label>
			          <input type="password" name="pass1" class="form-control" maxlength="6" placeholder="kata sandi" required/>
			 		  <span style="font-size:12px;">Password minimal 6 karakter, harus berupa angka.</span>	
			        </div>
			        <div class="form-group">
			          <label>Konfirmasi Kata Sandi</label>
			          <input type="password" name="pass2" maxlength="6" class="form-control" placeholder="konfirmasi kata sandi" required/>
			          <span style="font-size:12px;">Masukkan ulang kata sandi</span>	
			        </div>
			        <button class="btn btn-success" id="daftar"> Daftar Akun</button>
				</form><br>
				
				<br>
			</div>
		</div>

		<div class="col-md-6">
			<div class="container-fluid" style="width:70%;">
				<center><h4>Daftar sebagai Penjual</h4></center>
				<?php 
				echo $this->session->flashdata('notif_oke2');
				echo $this->session->flashdata('err_telp2');
				echo $this->session->flashdata('err_email2');
				echo $this->session->flashdata('err_pass2');
				echo $this->session->flashdata('err_passlen2');
				?>
				<form action="<?php echo site_url('daftar/prosespenjual') ?>" method="post">
					<div class="form-group">
			          <label>Nama Toko</label>
			          <input type="text" name="toko" class="form-control" placeholder="nama toko" required/>
			          
			        </div>
					<div class="form-group">
			          <label>Nama Lengkap</label>
			          <input type="text" name="nama" class="form-control" placeholder="nama lengkap" required/>
			          
			        </div>
			        <div class="form-group">
			          <label>Nomor Telepon</label>
			          <input type="text" name="telp" class="form-control"  placeholder="nomor telepon" required/>
			         <span style="font-size:12px;">Masukkan nomor telepon yang valid, demi kenyamanan belanja dan transaksi anda.</span>
			        </div>
			        <div class="form-group">
			          <label>Email</label>
			          <input type="email" name="email" class="form-control" placeholder="email" required/>
			          
			        </div>
			        <div class="form-group">
			          <label>Kata Sandi</label>
			          <input type="password" name="pass1" class="form-control" maxlength="6" placeholder="kata sandi" required/>
			          <span style="font-size:12px;">Password minimal 6 karakter, harus berupa angka.</span>	
			        </div>
			        <div class="form-group">
			          <label>Konfirmasi Kata Sandi</label>
			          <input type="password" name="pass2" class="form-control" maxlength="6" placeholder="konfirmasi kata sandi" required/>
			           <span style="font-size:12px;">Masukkan ulang kata sandi</span>
			        </div>
			        <button class="btn btn-info"> Daftar Akun</button>
				</form>
				<div class="oke"></div>
				<br>
			</div>
		</div>
	</div>

		<?php $this->load->view('v_foot') ?>
	</div>
</div>
</body>
</html>