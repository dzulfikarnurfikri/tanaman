<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Halaman Utama</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
<?php echo $this->session->flashdata('alert') ?>
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > Detail Produk</font> 
		</nav>
	</div>
	<?php if($detail){ ?>
	<div class="row">
		<div class="col-md-4">
			<div class="thumbnail">
				<img src="<?php echo base_url('produk/'.$detail->gambar_produk) ?>" width="200px" height="200px"  alt="<?php echo $detail->gambar_produk ?>" title="<?php echo $detail->nama_produk ?>">
				
			</div>
		
		</div>
		<div class="col-md-5">
			<div class="caption">
					
					<h3><?php echo $detail->nama_produk ?> </h4>
					<font>Jenis produk : <?php echo $detail->jenis_produk ?></font><br>
					<font style="font-weight:bold;">Stock : <?php echo $detail->stock ?></font><br><br>

					<div class="alert alert-success">Belanja nyaman, hati puas. <br> ongkos kirim <b>GRATIS!</b></div>
					<font style="font-weight:bold;">Deskripsi</font><br>
					<p><?php echo $detail->deskripsi ?></p>
					<br>
					<strong>Jumlah</strong>
					<form action="<?php echo site_url('keranjang/tambah/'.$detail->id_produk) ?>" id="myform" method="post">
					<div class="input-group" style="width:30%;">
			          <select name="jml" style="width:30%">
			          	<option value="1">1</option>
			          	<option value="2">2</option>
			          	<option value="3">3</option>
			          	<option value="4">4</option>
			          	<option value="5">5</option>
			          </select>
			      </div><br>
			      <h4>Profil penjual</h4>
			      <table border="0" width="100%" class="table">
			      	<tr>
			      		<td width="20%">Nama Toko</td>
			      		<td width="35%">: <b> <?php echo $detail->toko ?></b></td>
			      		<td width="15%">Telepon</td>
			      		<td width="30%">: <?php echo $detail->telepon ?></td>
			      	</tr>
			      	<tr>
			      		<td>Nama lengkap</td>
			      		<td>: <?php echo $detail->nama_penjual ?></td>
			      		<td>Email</td>
			      		<td>: <?php echo $detail->email ?></td>
			      	</tr>
			      	<tr>
			      		<td valign="top">Jenis kelamin</td>
			      		<td valign="top">: <?php echo $detail->jenis_kelamin ?></td>
			      		<td valign="top">Alamat</td>
			      		<td>: <?php echo $detail->alamat ?></td>
			      	</tr>
			      </table>
				</div>	  
						  
		</div>
		<div class="col-md-3">
			<center>
				<font style="font-weight:bold;font-size:18px;">Rp. <?php echo number_format($detail->harga,2,',','.') ?></font><br>
				<p style="color:#999;">Perubahan harga terakhir pada<br> <?php echo $detail->tanggal ?> </p>
				<?php if($this->session->userdata('status') == 'penjual'){ ?>
				&nbsp;
				<?php }else{ ?>
				<input type="submit" name="cart" class="btn btn-danger" value="Tambah ke keranjang" style="width:100%"/>
				<?php } ?>
				<br><br>
				<font style="font-weight:bold;">Dukungan Pengiriman</font>
				<img src="<?php echo base_url('images/jne.png') ?>"><br><br>
			</center>	  
					</form>		  
		</div>
	</div>
	<?php }else{ ?>
		<div class="alert alert-danger" role="alert">Tidak ada foto</div>
	<?php } ?>

	<?php $this->load->view('v_foot') ?>
</div>


	<script type="text/javascript">
		$(document).ready(function(){
			var count = 1;
			$('#plus').click(function(){
				if(count < 5){
					count++;
					var jml = count;
					$('#count').val(jml);
				}
			});

			$('#minus').click(function(){
				if(count > 1){
					count--;
					var jml = count;
					$('#count').val(jml);
				}
			});
		});
	</script>
</body>
</html>
<!--
	<div class="input-group">
          <span class="input-group-btn">
              <button type="button" class="btn btn-default" id="minus" onclick="minus()">
                  <span class="glyphicon glyphicon-minus"></span>
              </button>
          </span>
          <input type="text" class="form-control" value="1" id="count">
          <span class="input-group-btn">
              <button type="button" class="btn btn-default" id="plus" onclick="plus()">
                  <span class="glyphicon glyphicon-plus"></span>
              </button>
          </span>
      </div>
-->