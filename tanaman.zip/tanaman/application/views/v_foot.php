<nav class="navbar navbar-default">
	<div class="container-fluid" style="line-height:50px;color:#fff;">
		<center>
			Copyright &copy; 2017 Dzulfikar Nurfikri. All Rights Reserved. <a href="<?php echo site_url('home/tentang') ?>" style="color:#fff;">Tentang kami</a> | <a href="<?php echo site_url('home/prosedur') ?>" style="color:#fff;">Belanja</a> | <a href="<?php echo site_url('home/jualan') ?>" style="color:#fff;">Berjualan</a></font>
		</center>
	</div>
</nav>