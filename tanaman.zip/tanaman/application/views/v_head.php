<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?php echo base_url() ?>">Online Shop</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="dropdown">
          <a href="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Kategori <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="">Jenis Tanaman</a>
              <ul class="hov">
                <li><a href="<?php echo site_url('home/kategori/daun') ?>">Daun</a></li>
                <li><a href="<?php echo site_url('home/kategori/bunga') ?>">Bunga</a></li>
                <li><a href="<?php echo site_url('home/kategori/buah') ?>">Buah</a></li>
                <li><a href="<?php echo site_url('home/kategori/batang') ?>">Batang</a></li>
              </ul>
            </li>
            <li><a href="<?php echo site_url('home/kategori/aksesoris') ?>">Aksesoris</a></li>
          </ul>
        </li>
        <li><a href="<?php echo site_url('artikel') ?>">Artikel</a></li>
      </ul>
      
      <form action="<?php echo site_url('home') ?>" method="post" class="navbar-form navbar-left">
        <div class="form-group">
          <input type="text" class="form-control" name="txt" placeholder="Search">
        </div>
        <button type="submit" class="btn btn-default">Cari</button>
      </form>

      <ul class="nav navbar-nav navbar-right">
      <?php if($this->session->userdata('status') == 'penjual'){ ?>
      &nbsp;
      <?php }else{ ?>
      <li><a href="<?php echo site_url('keranjang') ?>">Keranjang</a></li>
      <?php } ?>
      <?php 
        if(!$this->session->userdata('logged_in')){
      ?>
        <li><a href="<?php echo site_url('daftar') ?>">Daftar</a></li>
        <li><a href="<?php echo site_url('masuk') ?>">Masuk</a></li>
      <?php }else{ ?>
        <li><a href="<?php echo site_url('akun') ?>"><?php echo $this->session->userdata('nama'); ?> </a></li>
        <li><a href="<?php echo site_url('masuk/keluar') ?>">Keluar</a></li>
      <?php } ?>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>