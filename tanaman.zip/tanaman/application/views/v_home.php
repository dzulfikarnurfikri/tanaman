<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Halaman Utama</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;">Beranda</font>
		</nav>
	</div>
	<div class="row">
		<div class="col-md-3">
			<?php $this->load->view('left') ?>
		</div>
		<div class="col-md-9">
				<?php 
					   	if($produk){
					   	foreach ($produk as $p) {
					   	?>
						  <div class="col-sm-6 col-md-4">
						    <div class="thumbnail">
						      <img src="<?php echo base_url('produk/'.$p['gambar_produk']) ?>" style="border:0px solid;height:240px;"  alt="<?php echo $p['gambar_produk'] ?>" title="<?php echo $p['nama_produk'] ?>">
						      <div class="caption">
						        <h4><?php echo substr($p['nama_produk'], 0,20) ?> ...</h4>
						        <font style="color:#ff0000;">Rp. <?php echo number_format($p['harga'],2,',','.') ?></font>
						        <p><a href="<?php echo site_url('home/detail/'.$p['id_produk']) ?>" class="btn btn-primary">Detail</a>
						      </div>
						    </div>
						  </div>
						  <?php 
							}}else{ ?>
							<div class="alert alert-danger" role="alert">Tidak ada produk</div>
							<?php } ?>
		</div>
	</div>

	<?php $this->load->view('v_foot') ?>
</div>


	<script type="text/javascript">
		var count = 1;
	    var countEl = document.getElementById("count");
	    function plus(){
	    	if(count <= 4){
	    		count++;
	        	countEl.value = count;
	    	}
	    }
	    function minus(){
	      if (count > 1) {
	        count--;
	        countEl.value = count;
	      }  
	    }

	</script>
</body>
</html>
<!--
	<div class="input-group">
          <span class="input-group-btn">
              <button type="button" class="btn btn-default" id="minus" onclick="minus()">
                  <span class="glyphicon glyphicon-minus"></span>
              </button>
          </span>
          <input type="text" class="form-control" value="1" id="count">
          <span class="input-group-btn">
              <button type="button" class="btn btn-default" id="plus" onclick="plus()">
                  <span class="glyphicon glyphicon-plus"></span>
              </button>
          </span>
      </div>
-->