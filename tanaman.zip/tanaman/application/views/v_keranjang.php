<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Halaman Utama</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > Keranjang Belanja</font> 
		</nav>
	</div>
	<div class="row">
		<div class="col-md-9">
				<?php echo $this->session->flashdata('alert') ?>
				<a href="<?php echo site_url('keranjang/kosongkanCart') ?>"><div class="kosongkan">
					Kosongkan Keranjang
				</div></a>
				<?php echo form_open('keranjang/update'); ?>
				<table cellpadding="6" cellspacing="0" style="width:100%;border-collapse:collapse;border:1px solid #999;" border="1">
					<tr style="height:30px;background-color:#eee;text-align:center;font-weight:bold;color:#666;font-size:14px;">
						<td width="25%">Nama Produk</td>
						<td width="15%">Jumlah Produk</td>
						<td width="20%">Harga Produk</td>
						<td width="25%">Subtotal</td>
						<td width="10%">Hapus</td>
					</tr>
					<?php if($this->cart->contents()){ ?>
					<?php $i = 1; ?>
					<?php foreach ($this->cart->contents() as $items){ ?>
					<?php echo form_hidden($i.'[rowid]', $items['rowid']); ?>
					<tr style="height:30px;">
					  <td style="padding:0 1%;">
					  
						<?php echo $items['name']; ?>
							<?php if ($this->cart->has_options($items['rowid']) == TRUE){ ?>
								<p>
									<?php foreach ($this->cart->product_options($items['rowid']) as $option_name => $option_value){ ?>
										<strong><?php echo $option_name; ?>:</strong> <?php echo $option_value; ?><br />
									<?php } ?>
								</p>
							<?php } ?>
					  </td>
					  <td align="center"><?php echo form_input(array('name' => 'qty'.$i, 'value' => $items['qty'], 'type' => 'number', 'max' => '5', 'min' => '1')); ?></td>
					  <td style="text-align:right;padding:0 1%;"><span style="float:left;">Rp.</span> <?php echo $this->cart->format_number($items['price']); ?></td>
					  <td style="text-align:right;padding:0 1%;"><span style="float:left;">Rp.</span> <?php echo $this->cart->format_number($items['subtotal']); ?></td>
					  <td align="center"><?php echo anchor('keranjang/hapus/'.$items['rowid'],'<font style="padding:0.5% 5%;border-radius:2px;background-color:#eee;border:1px solid #666;">X</font>') ?></td>
					</tr>
						<?php $i++; ?>
					<?php } ?>
							<tr style="height:30px;">
							  <td colspan="2"></td>
							  <td style="padding:0 1%;"><strong>Total</strong></td>
							  <td style="text-align:right;padding:0 1%;"><span style="float:left;">Rp.</span> <?php echo $this->cart->format_number($this->cart->total()); ?></td>
							</tr>
					<?php }else{ ?>
							<tr style="height:30px;">
								<td colspan="5" style="text-align:center;"><font style="color:#ff0000;">Keranjang Kosong</font></td>
							</tr>
					<?php } ?>
						</table><br>
				<input type="submit" style="padding:1% 3%;background-color:#2c3e50;color:#fff;font-size:14px;border-radius:4px;border:1px solid;cursor:pointer;" name="submit" value="&laquo; Update Keranjang &raquo;">
				<?php echo form_close(); ?>
				<br><?php echo anchor('home/index', '<font style="padding:1% 3%;background-color:#049372;color:#fff;font-size:14px;border-radius:4px;border:1px solid;cursor:pointer;">&laquo; Lanjut Belanja</font>') ?><br><br>
				<?php if($this->cart->total() > 0 ){ ?>
				<?php echo anchor('keranjang/verifikasi', '<font style="padding:1% 3%;background-color:#049372;color:#fff;font-size:14px;border-radius:4px;border:1px solid;cursor:pointer;">Lanjut Pembayaran &raquo;</font>') ?><br><br>
				<?php }else{ ?>
				<a href="" onclick="alert('Maaf, untuk melanjutkan ke pembayaran, Anda harus mengisi keranjang terlebih dahulu!');"><font style="padding:1% 3%;background-color:#049372;color:#fff;font-size:14px;border-radius:4px;border:1px solid;cursor:pointer;">Lanjut Pembayaran &raquo;</font></a><br><br>
				<?php } ?>
		</div>
	</div>

	<?php $this->load->view('v_foot') ?>
</div>


	<script type="text/javascript">
		var count = 1;
	    var countEl = document.getElementById("count");
	    function plus(){
	    	if(count <= 4){
	    		count++;
	        	countEl.value = count;
	    	}
	    }
	    function minus(){
	      if (count > 1) {
	        count--;
	        countEl.value = count;
	      }  
	    }

	</script>
</body>
</html>
<!--
	<div class="input-group">
          <span class="input-group-btn">
              <button type="button" class="btn btn-default" id="minus" onclick="minus()">
                  <span class="glyphicon glyphicon-minus"></span>
              </button>
          </span>
          <input type="text" class="form-control" value="1" id="count">
          <span class="input-group-btn">
              <button type="button" class="btn btn-default" id="plus" onclick="plus()">
                  <span class="glyphicon glyphicon-plus"></span>
              </button>
          </span>
      </div>
-->