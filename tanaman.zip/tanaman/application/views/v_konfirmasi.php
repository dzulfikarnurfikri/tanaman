<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Konfirmasi</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/default.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/zebra_datepicker.js') ?>"></script>
	<style type="text/css">
	a {
		color: #fff;
	}
	</style>
	<style type="text/css">
	.image-upload > input {
		display: none;
	}
	#tanggal1 {
		z-index: 999999;
	}
	</style>
	<script>
	    $(document).ready(function(){
	        $('#tanggal1').Zebra_DatePicker({
	            format: 'd-F-Y',
	            months : ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'],
	            days : ['Minggu','Senin','Selasa','Rabu','Kamis','Jum\'at','Sabtu'],
	            days_abbr : ['Minggu','Senin','Selasa','Rabu','Kamis','Jum\'at','Sabtu']
	        });
	    });
	</script>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > Konfirmasi pembayaran</font> 
		</nav>
	</div>
	<div class="row">
		<?php if($user){ ?>
		<div class="col-md-3">
			<img src="<?php echo base_url('foto/'.$foto) ?>" width="100%"><br><br>
			
		</div>
		<div class="col-md-9">
			<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
				<font style="color:#666;">
				<a href="<?php echo site_url('akun') ?>">Akun</a> | <a href="<?php echo site_url('akun/update/'.$id) ?>">Ubah akun</a> |
				<?php if($user->level == 'pelanggan'){ ?>
				<a href="<?php echo site_url('akun/pemesanan') ?>"> Pesanan saya </a> | 
				<a href="<?php echo site_url('keranjang/konfirmasi') ?>">Konfirmasi bayar pesanan</a>
				<?php }else{ ?>
				<a href="<?php echo site_url('akun/produkUser') ?>"> Produk saya </a> | 
				<a href="<?php echo site_url('keranjang/konfirmasi') ?>">Konfirmasi bayar sewa</a>
				<?php } ?>
				</font> 
			</nav>
			<?php echo $this->session->flashdata('error') ?>
			<h3>Konfirmasi pembayaran</h3>
			<form action="<?php echo site_url('keranjang/proseskonfirmasi') ?>" enctype="multipart/form-data" method="post">
		        <div class="form-group">
		          <label for="exampleInputEmail1">Kode Pemesanan</label>
		          <input type="text" name="kode" class="form-control" placeholder="kode pemesanan" required/>
		        </div>
		        <div class="form-group">
		          <label for="exampleInputEmail1">Total Pembayaran (Rp.)</label>
		          <input type="text" name="total" class="form-control" placeholder="total pembayaran" required/>
		        </div>
		        <div class="form-group">
		          <label for="exampleInputEmail1">Bukti Bayar</label>
		          <input type="file" name="userfile" required/>
		        </div>
		        <button type="submit" class="btn btn-primary">Konfirmasi</button>
		      </form><br><br>
		</div>
		<?php } ?>
	</div>

	<?php $this->load->view('v_foot') ?>
</div>
</body>
</html>
<!--
<div class="list-group">
			  <button type="button" id="akun" class="list-group-item">Akun</button>
			  <button type="button" id="alamat" class="list-group-item">Alamat</button>
			  <button type="button" id="sandi" class="list-group-item">Ganti kata sandi</button>
			</div>
-->