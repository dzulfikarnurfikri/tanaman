<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Laporan penjualan</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('datatables/dataTables.bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
	<style type="text/css">
	a {
		color: #fff;
	}
	</style>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > Laporan penjualan</font> 
		</nav>
	</div>
	<div class="row">
		<div class="col-md-3">
			<img src="<?php echo base_url('foto/'.$foto) ?>" width="100%"><br><br>
		</div>
		<div class="col-md-9">
			<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
				<font style="color:#666;">
				<a href="<?php echo site_url('akun') ?>">Akun</a> | <a href="<?php echo site_url('akun/update/'.$this->session->userdata('idu')) ?>">Ubah akun</a> |
				<?php if($user->level == 'pelanggan'){ ?>
				<a href="<?php echo site_url('akun/pemesanan') ?>"> Pesanan saya </a> | 
				<a href="<?php echo site_url('keranjang/konfirmasi') ?>">Konfirmasi bayar pesanan</a>
				<?php }else{ ?>
				<a href="<?php echo site_url('akun/produkUser') ?>"> Produk saya </a> |
				<a href="<?php echo site_url('akun/orderUser') ?>"> Data pemesanan </a> |
				<a href="<?php echo site_url('akun/laporanJual') ?>"> Laporan penjualan </a>
				<?php } ?></font> 
			</nav>
			<div class="box">
            <div class="box-body">
            	
             Cari berdasarkan tanggal :
						<form action="<?php echo site_url('akun/laporanJual') ?>" method="POST">
							<input type="date" name="tgl1"/>
							<input type="date" name="tgl2"/>
							<input type="submit" name="tgl" value="Cari">
						</form><br>
						<a target="blank" href="<?php echo site_url('akun/cetakLaporan/true') ?>" class="btn btn-primary">Cetak</a><br>
		            	<h3>Laporan penjualan</h3>
		              <table id="example1" class="table table-bordered table-striped">
		                <thead>
		                <tr>
		                  <th width="5%">No</th>
		                  <th width="15%">Kode pemesanan</th>
		                  <th width="15%">Tanggal</th>
		                  <th width="25%">Nama produk</th>
		                  <th width="15%">Status pengiriman</th>
		                  <th width="5%">Kuantiti</th>
		                  <th width="15%">Harga</th>
		                </tr>
		                </thead>
		                <tbody>

		                  <?php 
		                    $no = 1;
		                    foreach ($jual as $k) {
		                  ?>
		                  <tr>
		                    <td><?php echo $no++ ?></td>
		                    <td><?php echo $k['id_pemesanan'] ?></td>
		                    <td><?php echo $k['tanggal'] ?></td>
		                    <td><?php echo $k['nama_produk'] ?></td>
		                    <td><?php echo $k['status_pengiriman'] ?></td>
		                    <td align="center"><?php echo $k['jumlah'] ?></td>
		                   	<td>Rp. <?php echo number_format($k['harga'],2,',','.') ?></td>
		                  </tr>
		                 <?php } ?>
		                 <tr>
		    				<td colspan="6"><strong>Total</strong></td>
		    				<td>Rp. <?php echo number_format($sum->harga,2,',','.') ?></td>
		    			</tr>
		                </tbody>
		              </table>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
			
			
		</div>
	</div>

	<?php $this->load->view('v_foot') ?>
</div>

	<script src="<?php echo base_url('datatables/jquery.dataTables.min.js') ?>"></script>
	<script src="<?php echo base_url('datatables/dataTables.bootstrap.min.js') ?>"></script>
</body>
</html>