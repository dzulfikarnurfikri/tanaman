<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Masuk</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<div class="container" style="border:0px solid;margin-top:0px;">
	<div class="container-fluid">
		<center>
			<a href="<?php echo site_url() ?>"><h3>Online Shop</h3></a>
			<h4>Masuk ke Online Shop</h4>
			<P>Belum punya akun Online Shop ? Daftar <a href="<?php echo site_url('daftar') ?>">di sini</a></P>
		</center>
	</div>

	<div class="row">
		<div class="col-md-6">
			<div class="container-fluid" style="width:70%;">
			<center>
				<img src="<?php echo base_url('images/camera.png') ?>" width="100%">
			</center>
				
			</div>
		</div>

		<div class="col-md-6">
			<div class="container-fluid" style="width:70%;">
				<center><h4>Silahkan Masuk</h4></center>
				<?php 
				echo $this->session->flashdata('err_masuk');
				?>
				<form action="<?php echo site_url('masuk/prosesmasuk') ?>" method="post">
					
			        <div class="form-group">
			          <label>Email</label>
			          <input type="email" name="email" class="form-control" placeholder="email" required/>
			          
			        </div>
			        <div class="form-group">
			          <label>Kata Sandi</label>
			          <input type="password" name="pass" class="form-control" placeholder="kata sandi" required/>
			        </div>
			        <div class="form-group">
			          <label>Masuk sebagai</label>
			          <select name="akses" class="form-control">
			          	<option value="pelanggan">Pelanggan</option>
			          	<option value="penjual">Penjual</option>
			          </select>
			        </div>
			   		<div class="form-group">
			          <input type="checkbox" name="ingat"/> Ingat saya
			        </div>
			        <button class="btn btn-info"> Masuk ke Online Shop</button>
				</form>
				<div class="oke"></div>
				<br>
			</div>
		</div>
	</div>

		<?php $this->load->view('v_foot') ?>
	</div>
</div>
</body>
</html>