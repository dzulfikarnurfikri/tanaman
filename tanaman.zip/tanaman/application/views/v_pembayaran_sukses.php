<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Pembayaran sukses</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > Pembayaran sukses</font>
		</nav>
	</div>
	<div class="row">
		<div class="col-md-1">
			&nbsp;
		</div>
		<div class="col-md-11">
				<div class="container-fluid">
					<h4>Selamat, transaksi Anda berhasil.</h4>
					Silahkan tunggu 2 sampai 3 hari, pesanan Anda dalam proses pengiriman.<br>
					Terima kasih telah berbelanja di Adjiekaktus.com
				</div>
		</div>
	</div>

	<?php $this->load->view('v_foot') ?>
</div>
</body>
</html>