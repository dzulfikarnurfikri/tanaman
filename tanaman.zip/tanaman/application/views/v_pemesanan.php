<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Pemesanan saya</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('datatables/dataTables.bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
	<style type="text/css">
	a {
		color: #fff;
	}
	</style>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > Pemesanan saya</font> 
		</nav>
	</div>
	<div class="row">
		<div class="col-md-3">
			<img src="<?php echo base_url('foto/'.$foto) ?>" width="100%"><br><br>
		</div>
		<div class="col-md-9">
			<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
				<font style="color:#666;">
				<a href="<?php echo site_url('akun') ?>">Akun</a> | <a href="<?php echo site_url('akun/update/'.$this->session->userdata('idu')) ?>">Ubah akun</a> |
				<?php if($user->level == 'pelanggan'){ ?>
				<a href="<?php echo site_url('akun/pemesanan') ?>"> Pesanan saya </a> | 
				<a href="<?php echo site_url('keranjang/konfirmasi') ?>">Konfirmasi bayar pesanan</a>
				<?php }else{ ?>
				<a href="<?php echo site_url('akun/produkUser') ?>"> Produk saya </a> |
				<a href="<?php echo site_url('akun/orderUser') ?>"> Data pemesanan </a> |
				<a href="<?php echo site_url('akun/laporanJual') ?>"> Laporan penjualan </a>
				<?php } ?></font> 
			</nav>
			<div class="box">
            <div class="box-body">
            	<h3>Pemesanan saya</h3>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th width="5%">No</th>
                  <th width="15%">Kode Pemesanan</th>
                  <th width="20%">Nama penerima</th>
                  <th width="15%">Telepon</th>
                  <th width="5%">Alamat</th>
                  <th width="10%">Status</th>
                  <th width="10%">Tahap</th>
                  <th width="15%">Aksi</th>
                </tr>
                </thead>
                <tbody>

                  <?php 
                    $no = 1;
                    foreach ($produk as $k) {
                  ?>
                  <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $k['id_pemesanan'] ?></td>
                    <td><?php echo $k['nama_penerima'] ?></td>
                   	<td><?php echo $k['telepon_penerima'] ?></td>
                    <td><?php echo $k['alamat_penerima'] ?></td>
                    <td><?php echo $k['status'] ?></td>
                    <td><?php echo $k['tahap'] ?></td>
                    <td>
                     	<a href="<?php echo site_url('akun/detailpemesanan/'.$k['id_pemesanan']) ?>"><div class="btn btn-primary">Detail</div></a>
                      	<a href="<?php echo site_url('akun/hapuspemesanan/'.$k['id_pemesanan']) ?>" onclick="return confirm('Yakin ingin hapus ?')"><div class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</div></a>  
                    </td> 
                    
                  </tr>
                 <?php } ?>
    
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
			
			
		</div>
	</div>

	<?php $this->load->view('v_foot') ?>
</div>

	<script src="<?php echo base_url('datatables/jquery.dataTables.min.js') ?>"></script>
	<script src="<?php echo base_url('datatables/dataTables.bootstrap.min.js') ?>"></script>
	<script>
	  $(document).ready(function(){
	    $(function () {
	      $("#example1").DataTable();
	      $('#example2').DataTable({
	        "paging": true,
	        "lengthChange": false,
	        "searching": false,
	        "ordering": true,
	        "info": true,
	        "autoWidth": false
	      });
	    });
	  });
	 </script>
</body>
</html>