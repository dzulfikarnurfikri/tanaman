<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Pemesanan sukses</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > Pemesanan sukses</font>
		</nav>
	</div>
	<div class="row">
		<div class="col-md-1">
			&nbsp;
		</div>
		<div class="col-md-11">
				<div class="container-fluid">
					<h4>SELAMAT, PEMESANAN ANDA BERHASIL DIPROSES.</h4>
					Kode pemesanan Anda adalah <h3><?php echo $id ?></h3>
					Simpan kode tersebut, karena akan digunakan untuk konfirmasi pembayaran!<br>
					Silahkan transfer ke bank yang tercantum di website.
				
					Kemudian lakukan konfirmasi pembayaran jika sudah transfer, agar pemesanan Anda bisa segera kami kirim ke alamat Anda.<br>
					Terima kasih telah membeli produk kami.
				</div>
		</div>
	</div>

	<?php $this->load->view('v_foot') ?>
</div>
</body>
</html>