<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Produk saya</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('datatables/dataTables.bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
	<style type="text/css">
	a {
		color: #fff;
	}
	</style>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > Produk saya</font> 
		</nav>
	</div>
	<div class="row">
		<div class="col-md-3">
			<img src="<?php echo base_url('foto/'.$foto) ?>" width="100%"><br><br>
		</div>
		<div class="col-md-9">
			<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
				<font style="color:#666;">
				<a href="<?php echo site_url('akun') ?>">Akun</a> | <a href="<?php echo site_url('akun/update/'.$this->session->userdata('idu')) ?>">Ubah akun</a> |
				<?php if($user->level == 'pelanggan'){ ?>
				<a href="<?php echo site_url('akun/pemesanan') ?>"> Pesanan saya </a> | 
				<a href="<?php echo site_url('keranjang/konfirmasi') ?>">Konfirmasi bayar pesanan</a>
				<?php }else{ ?>
				<a href="<?php echo site_url('akun/produkUser') ?>"> Produk saya </a> |
				<a href="<?php echo site_url('akun/orderUser') ?>"> Data pemesanan </a> |
				<a href="<?php echo site_url('akun/laporanJual') ?>"> Laporan penjualan </a>
				<?php } ?></font> 
			</nav>
			<div class="box">
            <div class="box-body">
            	<a href="<?php echo site_url('akun/tambahProduk') ?>" class="btn btn-success">Tambah produk</a><br><br>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th width="5%">No</th>
                  <th width="15%">Nama</th>
                  <th width="15%">Jenis</th>
                  <th width="17%">Gambar</th>
                  <th width="13%">Harga</th>
                  <th width="5%">Qty</th>
                  <th width="10%">Status</th>
                  <th width="10%">Aksi</th>
                </tr>
                </thead>
                <tbody>

                  <?php 
                    $no = 1;
                    foreach ($produk as $k) {
                  ?>
                  <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $k['nama_produk'] ?></td>
                    <td><?php echo $k['jenis_produk'] ?></td>
                    <td> <img src="<?php echo base_url('produk/'.$k['gambar_produk']) ?>" width="100px" height="100px"> </td>
                   	<td>Rp. <?php echo number_format($k['harga']) ?></td>
                    <td><?php echo $k['stock'] ?></td>
                    <td><?php echo $k['status'] ?></td>
                    <td>
                     <form action="<?php echo site_url('akun/editproduk') ?>" method="post"  style="float:left;margin-right:4px;">
                      	<input type="hidden" name="id" value="<?php echo $k['id_produk'] ?>">
                      	<button class="btn btn-primary"><i class="fa fa-trash"></i> Edit</button>
                      </form>
                      <a href="<?php echo site_url('akun/hapusproduk/'.$k['id_produk']) ?>" onclick="return confirm('Yakin ingin hapus ?')"><div class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</div></a>  
                    </td> 
                    
                  </tr>
                 <?php } ?>
    
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
			
			
		</div>
	</div>

	<?php $this->load->view('v_foot') ?>
</div>

	<script src="<?php echo base_url('datatables/jquery.dataTables.min.js') ?>"></script>
	<script src="<?php echo base_url('datatables/dataTables.bootstrap.min.js') ?>"></script>
	<script>
	  $(document).ready(function(){
	    $(function () {
	      $("#example1").DataTable();
	      $('#example2').DataTable({
	        "paging": true,
	        "lengthChange": false,
	        "searching": false,
	        "ordering": true,
	        "info": true,
	        "autoWidth": false
	      });
	    });
	  });
	 </script>
</body>
</html>