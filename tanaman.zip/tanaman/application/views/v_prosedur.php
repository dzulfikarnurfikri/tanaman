<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Prosedur belanja</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > Prosedur belanja</font>
		</nav>
	</div>
	<div class="row">
		<div class="col-md-1">
			&nbsp;
		</div>
		<div class="col-md-11">
				<div class="container-fluid">
					<h4>Langkah Mudah Belanja Online di Online shop</h4>
					<img src="<?php echo base_url('images/beli.jpg') ?>">
					<center><h4>Menu beli</h4></center>
					<font style="font-weight:bold;">Langkah 1 &raquo; Cari produk</font><br>
					<font>Untuk menemukan produk yang kamu caari, ada 2 cara yang bisa kamu lakukan, yaitu :</font>
					<ul>
						<li>Ketik nama produk di dalam kolom pencarian</li>
						<li>Klik kategori-kategori yang ada di dalam Online Shop</li>
					</ul>
					<font style="font-weight:bold;">Langkah 2 &raquo; Masuk ke keranjang belanja</font><br>
					<font>Setelah ketemu produk yang kamu mau, klik gambar produk tersebut untuk melihat informasi lengkap tentang produk dan toko yang kamu pilih, antara lain :</font>
					<ul>
						<li>Informasi produk : berisi semua informasi penting tentang produk yang sedang kamu lihat</li>
						<li>Informasi penjual : berisi informasi lengkap tentang penjual</li>
						<li>Keterangan harga pas dan grosir (jika ada)</li>
					</ul>
					<font>Setelah yakin produk ingin dibeli, klik "Beli" maka pesanan akan masuk ke dalam keranjang belanja kamu.</font><br><br>
					<font style="font-weight:bold;">Langkah 3 &raquo; Masukkan alamat</font><br>
					<font>Setelah klik tombol <b>"Beli"</b>, isi formulir pemesanan dengan benar dan lengkap, seperti :</font><br>
					<ul>
						<li>Jumlah barang</li>
						<li>Alamat tujuan pengirim</li>
						<li>Catatan untuk penjual (Optional)</li>
					</ul>
					<font>Selanjutnya, klik <b>"Beli produk ini"</b>, dan kamu akan mendapatkan <b>kode pemesanan produk</b>.</font><br><br>
					<img src="<?php echo base_url('images/terima.jpg') ?>">
					<center><h4>Menu bayar</h4></center>
					<font>Dalam melakukan pembayaran melalui transfer Bank bisa melalui bank :</font>
					<ul>
						<li>BCA (3412670980)</li>
						<li>BNI (12099766512)</li>
						<li>BRI (45567809233254)</li>
					</ul>
					<p>Setelah melakukan pembayaran, foto bukti transfer kamu dan lakukan konfirmasi pembayaran dari kode pemesanan kamu, agar pembayaran yang kamu lakukan bisa segera dikonfirmasi.</p>
					<p><b>Konfirmasi pembayaran</b> dengan cara unggah foto bukti transfer kamu dan isi data konfrimasi pembayaran dengan benar.</p>
					<img src="<?php echo base_url('images/pembayaran.jpg') ?>" width="30%" height="150px">
					<center><h4>Terima barang</h4></center>
					<font style="font-weight:bold;">Langkah 1 &raquo; Lacak barang</font><br>
					<p>Setelah kamu melakukan konfirmasi pembayaran dan pembayaran kamu sudah dikonfirmasi pleh admin Online Shop, kemudia penjual memproses dan mengirim pesanan, kamu bisa melacak pesanan dengan cara kunjungi web resmi JNE <a href="#">www.jne.co.id/id/beranda</a> dan masukkan nomor resi yang kamu dapat dari penjual.</p>
					<font style="font-weight:bold;">Langkah 2 &raquo; Konfirmasi terima produk</font><br>
					<p>Jika produk kamu sudah sampai, jangan lupa untuk konfirmasi terima barang yah, caranya bisa inbox ke kontak admin Online Shop WA (089777231234), <br>
					Format inbox : (Kode pemesanan)_Sudah Terima <br>
					NB : Jika dalam waktu 1 minggu kamu tidak melakukan konfirmasi terima barang maka admin Online Shop akan mengkonfirmasi langsung bahwa produk telah kamu terima.</p>
				</div>
		</div>
	</div>

	<?php $this->load->view('v_foot') ?>
</div>
</body>
</html>