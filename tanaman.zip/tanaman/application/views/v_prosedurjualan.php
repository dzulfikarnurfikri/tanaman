<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Prosedur berjualan</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > Prosedur berjualan</font>
		</nav>
	</div>
	<div class="row">
		<div class="col-md-1">
		&nbsp;
		</div>
		<div class="col-md-11">
				<div class="container-fluid">
					<h4>Langkah mudah untuk menjadi penjual di Online Shop</h4>
					<img src="<?php echo base_url('images/jual.jpg') ?>">
					<br><br>
					<font style="font-weight:bold;">Langkah 1 &raquo; Melakukan pendaftaran</font><br>
					<font style="font-weight:bold;">Langkah 2 &raquo; Daftarkan Produk kamu dan Mulai Berjualan dengan cara Unggah satu produk dan mulai berjualan</font>
					<p>Bagi kamu yang Ingin menjadi mitra kerja,  untuk memasarkan produk tanaman hias kamu di website Online Shop dimana kami menerapakan sistem bagi hasil yaitu <b>“Kami Mengenakan komisi 10% untuk setiap transaksi ”</b> dan setelah kamu join kamu dapat memasarkan seluruh produk tanaman hias kamu, setelah kamu memperoleh pesanan dari pelanggan dan kamu telah mengirim barang pelanggan, Kami pihak Online Shop akan segera mengurus administrasi seluruh transaksi dan langsung mentransfer penghasilan kamu setiap minggunya.</p>
					
					<img src="<?php echo base_url('images/kirim.jpg') ?>">
					<br><br>
					<font>*Ketentuan Dalam Memasarkan Produk :</font>
					<ul>
						<li>Mengunggah Produk Tanaman hias sesuai dengan Jenis Tanaman Hias</li>
						<li>Mengisi data Produk dengan lengkap</li>
						<li>Memberikan deskripsi yang lengkap agar menarik minat pelanggan mendapatkan informasi produk yang akurat</li>
						<li>Menginput Daftar Harga : Harga = Harga Jual Produk + Ongkos Kirim untuk wilayah Jakarta</li>
					</ul>
					<br><br>
					<img src="<?php echo base_url('images/terimauang.jpg') ?>">
					<br><br>
				</div>
		</div>
	</div>

	<?php $this->load->view('v_foot') ?>
</div>
</body>
</html>