<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Update Akun</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/default.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/zebra_datepicker.js') ?>"></script>
	<style type="text/css">
	a {
		color: #fff;
	}
	</style>
	<script type="text/javascript" src="<?php echo base_url('nicEdit.js') ?>"></script>
	<script type="text/javascript">
	    bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
	</script>
	<style type="text/css">
	.image-upload > input {
		display: none;
	}
	#tanggal1 {
		z-index: 999999;
	}
	</style>
	<script>
	    $(document).ready(function(){
	        $('#tanggal1').Zebra_DatePicker({
	            format: 'd-F-Y',
	            months : ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'],
	            days : ['Minggu','Senin','Selasa','Rabu','Kamis','Jum\'at','Sabtu'],
	            days_abbr : ['Minggu','Senin','Selasa','Rabu','Kamis','Jum\'at','Sabtu']
	        });
	    });
	</script>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > <a style="color:#fff;" href="<?php echo site_url('akun/produkUser') ?>">Produk saya</a> > Tambah produk</font> 
		</nav>
	</div>
	<div class="row">
		<?php if($user){ ?>
		<div class="col-md-3">
			<img src="<?php echo base_url('foto/'.$foto) ?>" width="100%"><br><br>
			
		</div>
		<div class="col-md-9">
			<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
				<font style="color:#666;">
				<a href="<?php echo site_url('akun') ?>">Akun</a> | <a href="<?php echo site_url('akun/update/'.$id) ?>">Ubah akun</a> |
				<?php if($user->level == 'pelanggan'){ ?>
				<a href="<?php echo site_url('akun/pemesanan') ?>"> Pesanan saya </a> | 
				<a href="<?php echo site_url('keranjang/konfirmasi') ?>">Konfirmasi bayar pesanan</a>
				<?php }else{ ?>
				<a href="<?php echo site_url('akun/produkUser') ?>"> Produk saya </a> |
				<a href="<?php echo site_url('akun/orderUser') ?>"> Data pemesanan </a> |
				<a href="<?php echo site_url('akun/laporanJual') ?>"> Laporan penjualan </a>
				<?php } ?>
				</font> 
			</nav>
			<?php
			echo $this->session->flashdata('oke');
			echo $this->session->flashdata('err');
			?>
			<form action="<?php echo site_url('akun/prosestambahproduk') ?>" enctype="multipart/form-data" method="post">
		        <div class="form-group">
		          <label for="exampleInputEmail1">Nama Produk</label>
		          <input type="text" name="nama" class="form-control" placeholder="nama produk" required/>
		        </div>
		        <div class="form-group">
		          <label for="exampleInputEmail1">Jenis Produk</label>
		          <select class="form-control" name="jenis" required>
		          	<option value="">-Pilih-</option>
		          	<option value="Bunga">Bunga</option>
		          	<option value="Daun">Daun</option>
		          	<option value="Buah">Buah</option>
		          	<option value="Batang">Batang</option>
		          	<option value="Aksesoris">Aksesoris</option>
		          </select>
		        </div>
		        <div class="form-group">
		          <label for="exampleInputEmail1">Stock</label>
		          <input type="number" class="form-control" name="stock" min="1" required/>
		        </div>
		        <div class="form-group">
		          <label for="exampleInputEmail1">Harga (Rp)</label>
		          <input type="text" class="form-control" name="harga" required/>
		        </div>
		        <div class="form-group">
		          <label for="exampleInputEmail1">Gambar</label>
		          <input type="file" name="userfile" required/>
		        </div>
		        <div class="form-group">
		          <label for="exampleInputPassword1">Artikel</label>
		            <textarea name="area2" style="width:100%" rows="10"></textarea>
		        </div>
		        <button type="submit" class="btn btn-primary">Simpan Data</button>
		      </form><br><br>
		</div>
		<?php } ?>
	</div>

	<?php $this->load->view('v_foot') ?>
</div>
</body>
</html>
<!--
<div class="list-group">
			  <button type="button" id="akun" class="list-group-item">Akun</button>
			  <button type="button" id="alamat" class="list-group-item">Alamat</button>
			  <button type="button" id="sandi" class="list-group-item">Ganti kata sandi</button>
			</div>
-->