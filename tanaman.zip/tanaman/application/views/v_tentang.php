<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Tentang kami</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > Tentang kami</font>
		</nav>
	</div>
	<div class="row">
		<div class="col-md-1">
			&nbsp;
		</div>
		<div class="col-md-11">
				<div class="container-fluid">
				<h3>Tentang Kami</h3>
					<h4>Visi</h4>
					<p>Online Shop memperoleh kepercayaan dan kepuasan para pelanggan untuk  membantu memajukan ekonomi para UMKM Tanaman Hias serta membantu masyarakat dalam memasarkan produk tanaman hias.</p>
					<h4>Misi</h4>
					<p><ol type="a">
						<li>Menyediakan pelayanan yang terbaik bagi pelanggan</li>
						<li>Menyediakan tanaman kaktus berkualitas terbaik untuk dijadikan sebagai souvenir sesuai dengan kebutuhan pelanggan</li>
						<li>Mengutamakan kualitas produk</li>
						<li>Harga terjangkau</li>
						<li>Mempromosikan produk lokal dapat bersaing</li>
						<li>Menyediakan Jasa pemasaran produk tanaman hias bagi masyarakat</li>
					</ol></p>
					<p>Online Shop merupakan salah satu usaha yang menyediakan penjualan berbagai macam souvenir kaktus  serta  mempunyai jasa pemasaran produk bagi para penjual tanaman hias untuk memasarkan produk mereka melalui perantara Online Shop. Kaktus memulai usahanya sejak 31 Desember  2002.</p>
					<p>Dengan perkembangan zaman saat ini usaha Online Shop membuat sebuah ide dengan mendirikan mal online yang mempertemukan para penjual dengan pembeli dan memungkinkan terjadinya transaksi jual-beli online dengan lebih aman dan nyaman</p>
					<p>Website Adiji_kaktus.com telah menjadi salah satu online marketplace tanamann hias di wilayah jakarta yang masih tergolong baru, baik dalam jumlah anggota, toko online aktif, jumlah produk, maupun jumlah transaksinya</p>
					<h4>Office</h4>
					<p>Jln Peninggaran Timur II Rt.002/ Rw.09 Kebayoran lama utara, Jakarta Selatan</p>
					
					<h4>Hubungi</h4>
					<p><ul>
						<li>Penjual : 085694199466 (WA/SMS)</li>
						<li>Pelanggan : 085814104747 (WA/SMS)</li>
					</ul></p>
					<h4>Jam kerja operasional</h4>
					<p>Senin - Minggu : 09.00 - 22.00</p>
				</div>
		</div>
	</div>

	<?php $this->load->view('v_foot') ?>
</div>
</body>
</html>