<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Update Akun</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/default.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/zebra_datepicker.js') ?>"></script>
	<style type="text/css">
	a {
		color: #fff;
	}
	</style>
	<style type="text/css">
	.image-upload > input {
		display: none;
	}
	#tanggal1 {
		z-index: 999999;
	}
	</style>
	<script>
	    $(document).ready(function(){
	        $('#tanggal1').Zebra_DatePicker({
	            format: 'd-F-Y',
	            months : ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'],
	            days : ['Minggu','Senin','Selasa','Rabu','Kamis','Jum\'at','Sabtu'],
	            days_abbr : ['Minggu','Senin','Selasa','Rabu','Kamis','Jum\'at','Sabtu']
	        });
	    });
	</script>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > <a style="color:#fff;" href="<?php echo site_url('akun') ?>">Akun saya</a> > Ubah akun saya</font> 
		</nav>
	</div>
	<div class="row">
		<?php if($user){ ?>
		<form action="<?php echo site_url('akun/prosesupdate') ?>" enctype="multipart/form-data" method="post">
		<div class="col-md-3">
			<img src="<?php echo base_url('foto/'.$foto) ?>" width="100%"><br><br>
			<input type="hidden" name="gambar" value="<?php echo $foto ?>">
			<div class="image-upload">
				<label for="file-input">
					<img src="<?php echo base_url('images/camera.png') ?>" width="30px" height="30px"> Upload foto anda
				</label>
				<input id="file-input" type="file" name="userfile" />
			</div>
			<p style="font-size:12px;color:#666;">
				Besar file maksimum : 10 Megabytes.<br>
				Ekstensi file yang diizinkan : JPG, JPEG,PNG.
			</p>
		</div>
		<div class="col-md-9">
			<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
				<font style="color:#666;">
				<a href="<?php echo site_url('akun') ?>">Akun</a> | <a href="">Ubah akun</a> |
				<?php if($user->level == 'pelanggan'){ ?>
				<a href="<?php echo site_url('akun/pemesanan') ?>"> Pesanan saya </a> | 
				<a href="<?php echo site_url('keranjang/konfirmasi') ?>">Konfirmasi bayar pesanan</a>
				<?php }else{ ?>
				<a href="<?php echo site_url('akun/produkUser') ?>"> Produk saya </a> |
				<a href="<?php echo site_url('akun/orderUser') ?>"> Data pemesanan </a> |
				<a href="<?php echo site_url('akun/laporanJual') ?>"> Laporan penjualan </a>
				<?php } ?>
				</font> 
			</nav>
			<font style="font-size:16px;font-weight:bold;">Ubah Biodata Diri</font><br>
			<?php echo $this->session->flashdata('err') ?>
			<table border="0" width="100%">
				<tr style="height:40px;border-bottom:1px solid #eee;">
					<td width="15%">Nama</td>
					<td width="85%">: <input type="text" value="<?php echo $nama ?>" name="nama" required/></td>
				</tr>
				
				<tr style="height:40px;border-bottom:1px solid #eee;">
					<td>Jenis Kelamin</td><td>:
						<?php if($jk == 'Pria'){ ?>
						<input type="radio" name="jks" value="Pria" checked> Pria &nbsp;&nbsp;&nbsp;
						<input type="radio" name="jks" value="Wanita"> Wanita 
						<?php }elseif($jk == 'Wanita'){ ?>
						<input type="radio" name="jks" value="Pria" > Pria &nbsp;&nbsp;&nbsp;
						<input type="radio" name="jks" value="Wanita" checked> Wanita
						<?php }else{?>
						<input type="radio" name="jks" value="Pria" required> Pria &nbsp;&nbsp;&nbsp;
						<input type="radio" name="jks" value="Wanita" required> Wanita
						<?php } ?>
					</td>
				</tr>
				<tr style="height:40px;border-bottom:1px solid #eee;">
					<td>Tanggal Lahir</td>
					<td>:
					<select name="tgl" required>
						<option value="<?php echo $tgl ?>"><?php echo $tgl ?></option>
						<option value="">Tgl</option>
						<?php 
							for($tgls=1; $tgls<=31; $tgls++){
						?>
						<option value="<?php echo $tgls; ?>"><?php echo $tgls; ?></option>
						<?php } ?>
					</select>
					<select name="bln" required>
						<option value="<?php echo $bln ?>"><?php echo $bln ?></option>
						<option value="">Bln</option>
						<?php 
							$blns = array("Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus",
								"September","Oktober","November","Desember");
							foreach($blns as $no => $array){
						?>
						<option value="<?php echo $array; ?>"><?php echo $array; ?></option>
						<?php } ?>
					</select>

					<select name="thn" required>
						<option value="<?php echo $thn ?>"><?php echo $thn ?></option>
						<option value="">Thn</option>
						<?php 
							for($thns=1980; $thns<=2000; $thns++){
						?>
						<option value="<?php echo $thns; ?>"><?php echo $thns; ?></option>
						<?php } ?>
					</select></td>
				</tr>
			</table><br>
			<font style="font-size:16px;font-weight:bold;">Ubah Kontak</font><br>
			<table border="0" width="100%">
				<tr style="height:40px;border-bottom:1px solid #eee;">
					<td width="15%">Email</td><td width="1%">:</td>
					<td width="85%"> <input type="email" value="<?php echo $email ?>" name="email" /></td>
				</tr>
				<tr style="height:40px;border-bottom:1px solid #eee;">
					<td>Telepon</td><td>:</td><td> <input type="text" value="<?php echo $telp ?>" name="telp" /></td>
				</tr>
				<tr style="height:40px;border-bottom:1px solid #eee;">
					<td valign="top">Alamat</td><td valign="top">:</td><td><textarea rows="3" cols="30" name="alamat" required><?php echo $alamat ?></textarea><br>
					<font style="font-size:12px;">Isi alamat anda dengan lengkap. (Kelurahan, Kecamatan, Kabupaten, Provinsi)</font></td>
				</tr>
			</table><br>

			<font style="font-size:16px;font-weight:bold;">Ubah Kata Sandi</font><br>
			<table border="0" width="100%">
				<tr style="height:40px;border-bottom:1px solid #eee;">
					<td width="15%">Kata Sandi</td>
					<td width="85%">: <input type="password" maxlength="6" name="pass1" value="<?php echo $password ?>" /></td>
				</tr>
				<tr style="height:40px;border-bottom:1px solid #eee;">
					<td>Konfirmasi Kata Sandi</td><td>: <input type="password" maxlength="6" value="<?php echo $password ?>" name="pass2" /></td>
				</tr>
				<tr style="height:40px;border-bottom:1px solid #eee;">
					<td>&nbsp;</td><td>
					<input type="submit" name="update" class="btn btn-danger" value="Simpan" />
					<a href="<?php echo site_url('akun') ?>" class="btn btn-warning">Kembali</a></td>
				</tr>
			</table>
			</form>
		</div>
		<?php } ?>
	</div>

	<?php $this->load->view('v_foot') ?>
</div>
</body>
</html>
<!--
<div class="list-group">
			  <button type="button" id="akun" class="list-group-item">Akun</button>
			  <button type="button" id="alamat" class="list-group-item">Alamat</button>
			  <button type="button" id="sandi" class="list-group-item">Ganti kata sandi</button>
			</div>
-->