<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Verifikasi alamat</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js') ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/bootstrap.js') ?>"></script>
</head>
<body>
	<?php $this->load->view('v_head')  ?>
<div class="container">
	<div class="container-fluid">
		<nav class="navbar navbar-default" style="line-height:50px;padding-left:15px;">
			<font style="color:#fff;"><a style="color:#fff;" href="<?php echo base_url() ?>">Beranda</a> > Verifikasi alamat</font>
		</nav>
	</div>
	<div class="row">
		<div class="col-md-7">
			<font style="font-weight:bold;">Detail pembeli</font><br>
			<form action="<?php echo site_url('keranjang/pemesanan') ?>" method="post">
			<table width="100%" border="0">
				<tr style="height:40px">
					<td width="50%">Nama penerima</td><td width="50%">Telepon/Handphone</td>
				</tr>
				<tr style="height:40px">
					<td><input type="text" name="nama" value="<?php echo $u->nama_pelanggan ?>"></td>
					<td><input type="text" name="telp" value="<?php echo $u->telepon ?>"></td>
				</tr>
				<tr>
					<td colspan="2"><textarea name="alamat" style="width:77%" rows="3"><?php echo $u->alamat ?></textarea></td>
				</tr>
			</table><br>
			<font style="font-weight:bold;">Metode pembayaran</font><br>
			<input type="radio" name="metode" value="transfer" checked="true" /> Transfer<br><br>
			<font style="font-weight:bold;">Ketentuan pembayaran</font><br>
			<ul type="square">
				<li>Pembayaran dapat dilakukan melalui transfer ke rekening Bank BCA, Bank Mandiri, Bank BNI, atau Bank BRI</li>
			</ul>
		</div>
		<div class="col-md-5">
			<font style="font-weight:bold;">Ringkasan belanja</font><br>
			<table cellpadding="6" cellspacing="0" style="width:100%;" border="0">
					
					<?php if($this->cart->contents()){ ?>
					<?php $i = 1; ?>
					<?php foreach ($this->cart->contents() as $items){ ?>
					<?php echo form_hidden($i.'[rowid]', $items['rowid']); ?>
					<tr style="height:30px;">
					  <td style="padding:0 1%;">
						<?php echo $items['name']; ?>
							<?php if ($this->cart->has_options($items['rowid']) == TRUE){ ?>
								<p>
									<?php foreach ($this->cart->product_options($items['rowid']) as $option_name => $option_value){ ?>
										<strong><?php echo $option_name; ?>:</strong> <?php echo $option_value; ?><br />
									<?php } ?>
								</p>
							<?php } ?>
					  </td>
					  
					  <td style="text-align:right;padding:0 1%;">Rp. <?php echo $this->cart->format_number($items['subtotal']); ?></td>
					  
					</tr>
						<?php $i++; ?>
					<?php } ?>
							<tr style="height:30px;border-top:1px solid #999;">
							  
							  <td style="padding:0 1%;"><strong>Total</strong></td>
							  <td style="text-align:right;padding:0 1%;">Rp. <?php echo $this->cart->format_number($this->cart->total()); ?></td>
							</tr>
					<?php }else{ ?>
							<tr style="height:30px;">
								<td colspan="5" style="text-align:center;"><font style="color:#ff0000;">Keranjang Kosong</font></td>
							</tr>
					<?php } ?>
						</table>
					<input type="submit" class="btn btn-danger" name="simpan" value="Bayar">
					</form>
		</div>
	</div>

	<?php $this->load->view('v_foot') ?>
</div>

</body>
</html>