-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 12, 2017 at 08:42 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tanaman`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id_admin` varchar(5) NOT NULL,
  `nama_admin` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(6) NOT NULL,
  `level` varchar(7) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `nama_admin`, `email`, `password`, `level`) VALUES
('ADM01', 'Administrator', 'admin@yahoo.com', '123456', 'admin'),
('KPL01', 'Asep Saepudin', 'owner@yahoo.com', '123456', 'owner');

-- --------------------------------------------------------

--
-- Table structure for table `artikel`
--

CREATE TABLE IF NOT EXISTS `artikel` (
  `id_artikel` varchar(5) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `gambar` varchar(100) NOT NULL,
  `isi` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_artikel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `artikel`
--

INSERT INTO `artikel` (`id_artikel`, `judul`, `gambar`, `isi`, `tanggal`) VALUES
('A0001', 'bambu mini thailand', '305852_f7cd670d-7e88-48ea-ad13-758c1024c20e1.jpg', '<b>bambu mini thailand</b> memiliki nama latin bambusa sp adalah tanaman hias bambu dengan ukuran daun kecil yang lebat dan memiliki batang yang ramping.<div>iklim tumbuh optimal : dataran rendah sampai dataran tinggi</div><div>kkebutuhan sinar matahari : sepanjang hari</div><div>media tanam : tanah dan humus</div>', '2017-07-31 09:11:36'),
('A0002', 'terarrium super mini pot', '0_1fdf22aa-8d0d-4560-8580-77a43a6c6b9e_432_576.jpg', 'kayu diameter 5 -7 cm, terdiri dari 3 tanaman : media tanam rumput basah impor dan hidrogel di bagian bawah pot.', '2017-07-31 09:12:03');

-- --------------------------------------------------------

--
-- Table structure for table `detail_pemesanan`
--

CREATE TABLE IF NOT EXISTS `detail_pemesanan` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `id_pemesanan` varchar(20) NOT NULL,
  `id_produk` varchar(7) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `id_penjual` varchar(7) NOT NULL,
  `status_pengiriman` enum('belum dikirim','sudah dikirim') NOT NULL,
  `no_resi` varchar(20) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `detail_pemesanan`
--

INSERT INTO `detail_pemesanan` (`no`, `id_pemesanan`, `id_produk`, `jumlah`, `harga`, `id_penjual`, `status_pengiriman`, `no_resi`) VALUES
(12, 'ORD0001', 'PRK0001', 2, 10000, 'PNJ0001', 'sudah dikirim', 'JBRAB01068752316'),
(13, 'ORD0001', 'PRK0003', 1, 15000, 'PNJ0001', 'sudah dikirim', 'JBRAB01068752316'),
(14, 'ORD0002', 'PRK0008', 1, 80000, 'PNJ0002', 'sudah dikirim', 'CPUAB01068700021'),
(15, 'ORD0002', 'PRK0002', 2, 12000, 'PNJ0001', 'sudah dikirim', 'CPUAB01068700021');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE IF NOT EXISTS `pelanggan` (
  `id_pelanggan` varchar(8) NOT NULL,
  `nama_pelanggan` varchar(25) NOT NULL,
  `tanggal_lahir` varchar(2) NOT NULL,
  `bulan_lahir` varchar(15) NOT NULL,
  `tahun_lahir` varchar(4) NOT NULL,
  `jenis_kelamin` enum('Pria','Wanita') NOT NULL,
  `telepon` varchar(13) NOT NULL,
  `email` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `password` varchar(8) NOT NULL,
  `level` varchar(12) NOT NULL,
  `foto` text NOT NULL,
  `tanggal_daftar` date NOT NULL,
  PRIMARY KEY (`id_pelanggan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama_pelanggan`, `tanggal_lahir`, `bulan_lahir`, `tahun_lahir`, `jenis_kelamin`, `telepon`, `email`, `alamat`, `password`, `level`, `foto`, `tanggal_daftar`) VALUES
('PLGN001', 'Agung Himawan', '11', 'Februari', '1993', 'Pria', '087777777777', 'agung@yahoo.com', 'jalan setia kawan no 32 jakarta barat', '123456', 'pelanggan', '01-permata.png', '2017-06-01'),
('PLGN002', 'Uus Agustiana', '11', 'Maret', '1995', 'Pria', '082222222222', 'uus@yahoo.com', 'jalan tanah abang, jakarta pusat.', '123456', 'pelanggan', 'akun.png', '2017-07-31');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE IF NOT EXISTS `pembayaran` (
  `id_pembayaran` varchar(8) NOT NULL,
  `id_pemesanan` varchar(20) NOT NULL,
  `total_pembayaran` int(11) NOT NULL,
  `file` text NOT NULL,
  `tanggal_pembayaran` date NOT NULL,
  PRIMARY KEY (`id_pembayaran`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_pemesanan`, `total_pembayaran`, `file`, `tanggal_pembayaran`) VALUES
('KBB00001', 'ORD0001', 25000, 'TRANSFER-BCA.jpg', '2017-08-07'),
('KBB00002', 'ORD0002', 92000, 'TRANSFER-BCA1.jpg', '2017-08-07');

-- --------------------------------------------------------

--
-- Table structure for table `pemesanan`
--

CREATE TABLE IF NOT EXISTS `pemesanan` (
  `id_pemesanan` varchar(7) NOT NULL,
  `id_pelanggan` varchar(11) NOT NULL,
  `nama_penerima` varchar(25) NOT NULL,
  `telepon_penerima` varchar(13) NOT NULL,
  `alamat_penerima` text NOT NULL,
  `status` enum('lunas','belum lunas') NOT NULL,
  `tahap` enum('proses','selesai') NOT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id_pemesanan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemesanan`
--

INSERT INTO `pemesanan` (`id_pemesanan`, `id_pelanggan`, `nama_penerima`, `telepon_penerima`, `alamat_penerima`, `status`, `tahap`, `tanggal`) VALUES
('ORD0001', 'PLGN001', 'Agung Himawan', '087777777777', 'jalan setia kawan no 32 jakarta barat', 'lunas', 'selesai', '2017-08-07'),
('ORD0002', 'PLGN002', 'Uus Agustiana', '082222222222', 'jalan petojo vij, jakarta pusat.', 'lunas', 'selesai', '2017-07-01');

-- --------------------------------------------------------

--
-- Table structure for table `penjual`
--

CREATE TABLE IF NOT EXISTS `penjual` (
  `id_penjual` varchar(7) NOT NULL,
  `toko` varchar(50) NOT NULL,
  `nama_penjual` varchar(25) NOT NULL,
  `tanggal_lahir` varchar(2) NOT NULL,
  `bulan_lahir` varchar(15) NOT NULL,
  `tahun_lahir` varchar(4) NOT NULL,
  `jenis_kelamin` enum('Pria','Wanita') NOT NULL,
  `telepon` varchar(13) NOT NULL,
  `email` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `password` varchar(8) NOT NULL,
  `level` varchar(13) NOT NULL,
  `foto` text NOT NULL,
  `tanggal_daftar` date NOT NULL,
  PRIMARY KEY (`id_penjual`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjual`
--

INSERT INTO `penjual` (`id_penjual`, `toko`, `nama_penjual`, `tanggal_lahir`, `bulan_lahir`, `tahun_lahir`, `jenis_kelamin`, `telepon`, `email`, `alamat`, `password`, `level`, `foto`, `tanggal_daftar`) VALUES
('PNJ0001', 'Sarana Makmur Sejati', 'Wiwin Nurlaela', '11', 'Januari', '1990', 'Wanita', '085666777888', 'wiwin@yahoo.com', 'jalan bukit duri, jakarta barat.', '123456', 'penjual', 'akun.png', '2017-06-01'),
('PNJ0002', 'Sumber Rezeki', 'Nita Aprilia', '11', 'April', '1994', 'Wanita', '087667890780', 'nita@yahoo.com', 'jalan rawa buaya, jakarta barat.', '123456', 'penjual', 'akun.png', '2017-07-31');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE IF NOT EXISTS `produk` (
  `id_produk` varchar(7) NOT NULL,
  `nama_produk` varchar(50) NOT NULL,
  `gambar_produk` varchar(100) NOT NULL,
  `jenis_produk` varchar(25) NOT NULL,
  `deskripsi` text NOT NULL,
  `stock` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `status` varchar(15) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_penjual` varchar(10) NOT NULL,
  PRIMARY KEY (`id_produk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `gambar_produk`, `jenis_produk`, `deskripsi`, `stock`, `harga`, `status`, `tanggal`, `id_penjual`) VALUES
('PRK0001', 'Overview Of Mini Pot Bunga Hias Kaktus Tanaman', 'Pot_Bunga.jpg', 'Aksesoris', 'mini pot untuk menanam bunga atau tanaman kecil lainnya, menghiasi semua sudut ruangan rumah anda.<div>features : </div><div>plant your own flower</div><div>anda dapat menghiasi rumah dengan bunga kaktus atau tanaman kecil lainnya.</div><div>portable</div><div>karena pot berukuran mini, anda dapat memindahkan pot kemanapun sesuka hati anda.</div><div><br></div>', 3, 10000, 'publish', '2017-07-31 06:43:06', 'PNJ0001'),
('PRK0002', 'Bunga Mawar Merah', 'Mawar.jpg', 'Bunga', 'tanaman hidup siap tanam<div>bunga mawar merah</div><div>tinggi 15  - 40 cm</div><div>barang terbatas, buruan diorder.</div>', 3, 12000, 'publish', '2017-07-31 06:46:05', 'PNJ0001'),
('PRK0003', 'Daun Zebra Besar Tipe B', '0_30ddebb6-5f19-4dc4-99b4-1ac64e4a265f_640_640.jpg', 'Daun', 'daun artifical terbuat dari kain<div>hanya daun tidak termasuk pot</div><div><br></div>', 4, 15000, 'publish', '2017-07-31 06:47:43', 'PNJ0001'),
('PRK0004', 'Nangka Mini', '17201085_83ef7576-f36e-4000-935f-653a15a75c90_800_800.jpg', 'Buah', 'tinggi +/- 70 cm<div>asal bibit : okulasi</div><div>keaslian dan kualitas bibit, kami jamin.</div><div>bibit unggulan</div>', 5, 25000, 'publish', '2017-07-31 06:50:27', 'PNJ0001'),
('PRK0005', 'Bambu Mini Thailand', '305852_f7cd670d-7e88-48ea-ad13-758c1024c20e.jpg', 'Batang', 'bambu mini thailan memiliki nama latin bambusa sp adalah tanaman hias bambu dengan ukuran daun kecil yang lebat dan memiliki batang yang ramping.<div>iklim tumbuh optimal : dataran rendah sampai dataran tinggi</div><div>kkebutuhan sinar matahari : sepanjang hari</div><div>media tanam : tanah dan humus</div>', 5, 40000, 'publish', '2017-07-31 06:53:53', 'PNJ0001'),
('PRK0006', 'Bunga Anggrek Latex 5', '112719_cc4d8907-0c48-44ad-a873-3fa0e25b9425.jpg', 'Bunga', 'bahan : latex real touch artificial flower<div>tinggi keseluruhan : 54 cm</div><div>tinggi kelompok bunga : 18 cm</div><div>tinggi tangkai : 36 cm</div><div>batang lentur, mudah dalam perangkaian.</div>', 5, 55000, 'publish', '2017-07-31 20:41:33', 'PNJ0002'),
('PRK0007', 'Daun Garlan Peacock', 'tanaman_hias_calatea.jpg', 'Daun', 'daun artificial terbuat dari kain<div>panjang 2,2 m</div><div><br></div>', 5, 60000, 'publish', '2017-07-31 20:43:46', 'PNJ0002'),
('PRK0008', 'Buah Naga Mini', '17201085_83ef7576-f36e-4000-935f-653a15a75c90_800_8001.jpg', 'Buah', 'buah naga mini merupakan tanaman yang cocok ditanam sebagai tabulampot hias.<div>nama ilmiah : Ephypillum Guatemalense Monstrose </div><div>asal bibit : stek batang</div><div>kebutuhan sinar matahari : di bawah naungan</div>', 4, 80000, 'publish', '2017-07-31 20:47:38', 'PNJ0002');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
